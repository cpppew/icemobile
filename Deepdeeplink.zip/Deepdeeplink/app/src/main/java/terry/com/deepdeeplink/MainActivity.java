package terry.com.deepdeeplink;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.util.Log;
import android.net.Uri;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

public class MainActivity extends ActionBarActivity {

    private Uri APP_URI;
    private Uri WEB_URL;
    private String title;
    private GoogleApiClient mClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mClient = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
        onNewIntent(getIntent());
    }

    protected void onNewIntent(Intent intent) {
        String str_app = "android-app://terry.com.deepdeeplink/terry";
        String str_web = "http://cpppew.github.io/icemobile/";
        String str_title = "Cpppew";
        String action = intent.getAction();
            if(action.equals("android.intent.action.VIEW")) {
                String data = intent.getDataString();
                if(data != null){
                    if(data.equals("terry://spike")) {
                        str_app += "/spike";
                        str_web += "spike/";
                        str_title += ", spike";
                        setContentView(R.layout.activity_spike);
                    } else if(data.equals("terry://demo")) {
                        str_app += "/demo";
                        str_web += "demo/";
                        str_title += ", demo";
                        setContentView(R.layout.activity_demo);
                    } else if(data.equals("terry://courseware")) {
                        str_app += "/courseware";
                        str_web += "courseware/";
                        str_title += ", courseware";
                        setContentView(R.layout.activity_courseware);
                    }else {
                        setContentView(R.layout.activity_main);
                    }
                }
            }else {
                setContentView(R.layout.activity_main);

            }
        title  = str_title;
        APP_URI = Uri.parse(str_app);
        WEB_URL = Uri.parse(str_web);
    }

    @Override
    public void onStart() {
        super.onStart();
        // Connect your client
        mClient.connect();
        // Construct the Action performed by the user
        Action viewAction = Action.newAction(Action.TYPE_VIEW, title, WEB_URL, APP_URI);
        // Call the App Indexing API start method after the view has completely rendered
        AppIndex.AppIndexApi.start(mClient, viewAction);
    }

    @Override
    public void onStop() {
        // Call end() and disconnect the client
        Action viewAction = Action.newAction(Action.TYPE_VIEW, title, WEB_URL, APP_URI);
        AppIndex.AppIndexApi.end(mClient, viewAction);
        mClient.disconnect();
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
