package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.cathaypacific.ice.AndroidHelper;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_cx_android extends JSLibrary {

 
 
	public static final String enableHardwareAcceleration = "enableHardwareAcceleration";
 
 
	public static final String isHardwareAccelerationEnabled = "isHardwareAccelerationEnabled";
 
 
	public static final String getPixelDensity = "getPixelDensity";
 
 
	public static final String disableViewHardwareAcceleration = "disableViewHardwareAcceleration";
 
	String[] methods = { enableHardwareAcceleration, isHardwareAccelerationEnabled, getPixelDensity, disableViewHardwareAcceleration };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[0];
 return libs;
 }



	public ND_cx_android(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.enableHardwareAcceleration( );
 
 			break;
 		case 1:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.isHardwareAccelerationEnabled( );
 
 			break;
 		case 2:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.getPixelDensity( );
 
 			break;
 		case 3:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.disableViewHardwareAcceleration( );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "cx.android";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] enableHardwareAcceleration( ){
 
		Object[] ret = null;
 com.cathaypacific.ice.AndroidHelper.enableHardwareAcceleration( );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] isHardwareAccelerationEnabled( ){
 
		Object[] ret = null;
 Boolean val = new Boolean(com.cathaypacific.ice.AndroidHelper.isHardwareAccelerationEnabled( ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] getPixelDensity( ){
 
		Object[] ret = null;
 Double val = new Double(com.cathaypacific.ice.AndroidHelper.getPixelDensity( ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] disableViewHardwareAcceleration( ){
 
		Object[] ret = null;
 com.cathaypacific.ice.AndroidHelper.disableViewHardwareAcceleration( );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
};
