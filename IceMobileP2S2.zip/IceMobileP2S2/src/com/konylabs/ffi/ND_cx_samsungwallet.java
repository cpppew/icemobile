package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.cathaypacific.ice.SamsungWalletUtil;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_cx_samsungwallet extends JSLibrary {

 
	String[] methods = { };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[1];
 libs[0] = new SamsungWalletUtil();
 return libs;
 }



	public ND_cx_samsungwallet(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "cx.samsungwallet";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 


class SamsungWalletUtil extends JSLibrary {

 
 
	public static final String isSamsungWalletInstalled = "isSamsungWalletInstalled";
 
 
	public static final String showMbpOnSamsungWallet = "showMbpOnSamsungWallet";
 
 
	public static final String isAndroidVersionIceCreamAbove = "isAndroidVersionIceCreamAbove";
 
	String[] methods = { isSamsungWalletInstalled, showMbpOnSamsungWallet, isAndroidVersionIceCreamAbove };

	public Object createInstance(final Object[] params) {
 return new com.cathaypacific.ice.SamsungWalletUtil(
 );
 }


	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen < 1 || paramLen > 2){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 java.lang.String packageName0 = null;
 if(params[0+inc] != null && params[0+inc] != LuaNil.nil) {
 packageName0 = (java.lang.String)params[0+inc];
 }
 ret = this.isSamsungWalletInstalled(params[0]
 ,packageName0
 );
 
 			break;
 		case 1:
 if (paramLen < 1 || paramLen > 2){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 java.lang.String ticketId1 = null;
 if(params[0+inc] != null && params[0+inc] != LuaNil.nil) {
 ticketId1 = (java.lang.String)params[0+inc];
 }
 ret = this.showMbpOnSamsungWallet(params[0]
 ,ticketId1
 );
 
 			break;
 		case 2:
 if (paramLen < 0 || paramLen > 1){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 ret = this.isAndroidVersionIceCreamAbove(params[0]
 );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "SamsungWalletUtil";
	}

	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] isSamsungWalletInstalled( Object self ,java.lang.String inputKey0
 ){
 
		Object[] ret = null;
 Boolean val = new Boolean(((com.cathaypacific.ice.SamsungWalletUtil)self).isSamsungWalletInstalled( inputKey0
 ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] showMbpOnSamsungWallet( Object self ,java.lang.String inputKey0
 ){
 
		Object[] ret = null;
 ((com.cathaypacific.ice.SamsungWalletUtil)self).showMbpOnSamsungWallet( inputKey0
 );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] isAndroidVersionIceCreamAbove( Object self ){
 
		Object[] ret = null;
 Boolean val = new Boolean(((com.cathaypacific.ice.SamsungWalletUtil)self).isAndroidVersionIceCreamAbove( ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
}

};
