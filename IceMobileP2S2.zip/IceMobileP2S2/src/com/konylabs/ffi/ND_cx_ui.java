package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.cathaypacific.ice.NavPanelOverlayCtl;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_cx_ui extends JSLibrary {

 
	String[] methods = { };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[1];
 libs[0] = new NavPanelOverlayCtl();
 return libs;
 }



	public ND_cx_ui(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "cx.ui";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 


class NavPanelOverlayCtl extends JSLibrary {

 
 
	public static final String show = "show";
 
 
	public static final String dismiss = "dismiss";
 
	String[] methods = { show, dismiss };

	public Object createInstance(final Object[] params) {
 return new com.cathaypacific.ice.NavPanelOverlayCtl(
 );
 }


	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen < 1 || paramLen > 2){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 com.konylabs.vm.Function onClickCallback0 = null;
 if(params[0+inc] != null && params[0+inc] != LuaNil.nil) {
 onClickCallback0 = (com.konylabs.vm.Function)params[0+inc];
 }
 ret = this.show(params[0]
 ,onClickCallback0
 );
 
 			break;
 		case 1:
 if (paramLen < 0 || paramLen > 1){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 ret = this.dismiss(params[0]
 );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "NavPanelOverlayCtl";
	}

	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] show( Object self ,com.konylabs.vm.Function inputKey0
 ){
 
		Object[] ret = null;
 ((com.cathaypacific.ice.NavPanelOverlayCtl)self).show( (com.konylabs.vm.Function)inputKey0
 );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] dismiss( Object self ){
 
		Object[] ret = null;
 ((com.cathaypacific.ice.NavPanelOverlayCtl)self).dismiss( );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
}

};
