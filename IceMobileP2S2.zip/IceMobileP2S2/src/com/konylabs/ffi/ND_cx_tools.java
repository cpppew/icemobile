package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.cathaypacific.tools.Tool;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_cx_tools extends JSLibrary {

 
 
	public static final String getDP = "getDP";
 
 
	public static final String isTab = "isTab";
 
	String[] methods = { getDP, isTab };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[0];
 return libs;
 }



	public ND_cx_tools(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.getDP( );
 
 			break;
 		case 1:
 if (paramLen != 0){ return new Object[] {new Double(100),"Invalid Params"}; }
 ret = this.isTab( );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "cx.tools";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] getDP( ){
 
		Object[] ret = null;
 java.util.Hashtable retval = com.cathaypacific.tools.Tool.getDp( );
 LuaTable val = TableLib.convertToLuaTable(retval);
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] isTab( ){
 
		Object[] ret = null;
 Boolean val = new Boolean(com.cathaypacific.tools.Tool.isTablet( ));
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
};
