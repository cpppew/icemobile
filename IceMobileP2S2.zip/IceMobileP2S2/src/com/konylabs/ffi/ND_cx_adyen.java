package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.adyen.clientencryption.PaymentResponseEncryption;
import com.adyen.clientencryption.PaymentRequestEncryption;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_cx_adyen extends JSLibrary {

 
 
	public static final String getEncryptedCardData = "getEncryptedCardData";
 
	String[] methods = { getEncryptedCardData };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[1];
 libs[0] = new PaymentResponseEncryption();
 return libs;
 }



	public ND_cx_adyen(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen != 7){ return new Object[] {new Double(100),"Invalid Params"}; }
 java.lang.String userCardNum0 = null;
 if(params[0] != null && params[0] != LuaNil.nil) {
 userCardNum0 = (java.lang.String)params[0];
 }
 java.lang.String cardExpiryYear0 = null;
 if(params[1] != null && params[1] != LuaNil.nil) {
 cardExpiryYear0 = (java.lang.String)params[1];
 }
 java.lang.String cardExpiryMonth0 = null;
 if(params[2] != null && params[2] != LuaNil.nil) {
 cardExpiryMonth0 = (java.lang.String)params[2];
 }
 java.lang.String cardCvc0 = null;
 if(params[3] != null && params[3] != LuaNil.nil) {
 cardCvc0 = (java.lang.String)params[3];
 }
 java.lang.String cardHolderName0 = null;
 if(params[4] != null && params[4] != LuaNil.nil) {
 cardHolderName0 = (java.lang.String)params[4];
 }
 java.lang.String serverDateString0 = null;
 if(params[5] != null && params[5] != LuaNil.nil) {
 serverDateString0 = (java.lang.String)params[5];
 }
 java.lang.String publicKey0 = null;
 if(params[6] != null && params[6] != LuaNil.nil) {
 publicKey0 = (java.lang.String)params[6];
 }
 ret = this.getEncryptedCardData( userCardNum0, cardExpiryYear0, cardExpiryMonth0, cardCvc0, cardHolderName0, serverDateString0, publicKey0 );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "cx.adyen";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] getEncryptedCardData( java.lang.String inputKey0, java.lang.String inputKey1, java.lang.String inputKey2, java.lang.String inputKey3, java.lang.String inputKey4, java.lang.String inputKey5, java.lang.String inputKey6 ){
 
		Object[] ret = null;
 java.lang.String val = com.adyen.clientencryption.PaymentRequestEncryption.encrypt( inputKey0
 , inputKey1
 , inputKey2
 , inputKey3
 , inputKey4
 , inputKey5
 , inputKey6
 );
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 


class PaymentResponseEncryption extends JSLibrary {

 
 
	public static final String getEncryptedAESKey = "getEncryptedAESKey";
 
 
	public static final String decrypt = "decrypt";
 
	String[] methods = { getEncryptedAESKey, decrypt };

	public Object createInstance(final Object[] params) {
 return new com.adyen.clientencryption.PaymentResponseEncryption(
 (java.lang.String)params[0] );
 }


	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen < 0 || paramLen > 1){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 ret = this.getEncryptedAESKey(params[0]
 );
 
 			break;
 		case 1:
 if (paramLen < 1 || paramLen > 2){ return new Object[] {new Double(100),"Invalid Params"};}
 inc = 1;
 
 java.lang.String encryptedBase641 = null;
 if(params[0+inc] != null && params[0+inc] != LuaNil.nil) {
 encryptedBase641 = (java.lang.String)params[0+inc];
 }
 ret = this.decrypt(params[0]
 ,encryptedBase641
 );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "PaymentResponseEncryption";
	}

	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] getEncryptedAESKey( Object self ){
 
		Object[] ret = null;
 java.lang.String val = ((com.adyen.clientencryption.PaymentResponseEncryption)self).encryptAESKey( );
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] decrypt( Object self ,java.lang.String inputKey0
 ){
 
		Object[] ret = null;
 java.lang.String val = ((com.adyen.clientencryption.PaymentResponseEncryption)self).decrypt( inputKey0
 );
 
 			ret = new Object[]{val, new Double(0)};
 		return ret;
	}
 
}

};
