package com.kony.utils;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import java.lang.reflect.Field;

public class ResourceManager {

    private static Context baseContext;
    private static Typeface _widgetFont = null;
    private static Typeface _widgetTitleFont = null;

    public static Context getContext()
    {
        return baseContext;
    }
    public static void setContext(Context ctx) {
        if (baseContext == null)
            baseContext = ctx;
    }

    public static Typeface getWidgetTypeFace()
    {
        if (_widgetFont == null) {
            if (baseContext == null) return null;

            _widgetFont = Typeface.createFromAsset(baseContext.getAssets(), "fonts/AktivGrotesk-Regular.ttf");
        }
        return _widgetFont;
    }
    
    public static Typeface getWidgetTitleTypeFace()
    {
        if (_widgetTitleFont == null) {
            if (baseContext == null) return null;

            _widgetTitleFont = Typeface.createFromAsset(baseContext.getAssets(), "fonts/AktivGrotesk-Light.ttf");
        }
        return _widgetTitleFont;
    }
    
    public static Typeface getWidgetTypeFace(String name)
    {
        if (_widgetFont == null) {
            if (baseContext == null) return null;

            _widgetFont = Typeface.createFromAsset(baseContext.getAssets(), "fonts/"+name+".ttf");
        }
        return _widgetFont;
    }
    
    public static View inflateLayout(int rId) {
        if (baseContext == null) {
            return null;
        }
        return LayoutInflater.from(baseContext).inflate(rId, null);
    }
    public static int getResourceId(String name, String type) {
        if (baseContext == null) {
            return 0;
        }
        return getResourceId(baseContext, name, type);
    }

    public static int[] getStyleableResourceIds(String name)
    {
//        Log.d("ResourceManager", "====getStyleableResourceIds=" + name);
        if (baseContext != null)
        {
            try
            {
                Field[] fields2 = Class.forName(baseContext.getPackageName() + ".R$styleable").getFields();

                for (Field f : fields2)
                {
                    if (f.getName().equals(name))
                    {
                        return (int[])f.get(null);

//                        Log.d("ResourceManager", "====getStyleableResourceIds=" + name + "=" + f.toString());
//
//                        Log.d("ResourceManager", "====ret=" + name + "=" + ret.toString());

//                        return ret;
                    }
                }

            }
            catch (Throwable t)
            {
                Log.d("ResourceManager", "====getStyleableResourceIds=ex=" + name);
            }
        }
        return new int[0];
    }

    public static int getResourceId(Context mContext, String name, String type) {
        return mContext.getResources().getIdentifier(name, type, mContext.getPackageName());
    }
    public static int getResourceColor(String name) {
        if (baseContext == null) {
            return 17170443;
        }
        int tmp = getResourceId(baseContext, name, "color");
        if (tmp > 0)
            return baseContext.getResources().getColor(tmp);
        return 17170443;
    }
}
