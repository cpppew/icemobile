package com.cathaypacific.icecalendar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;
import com.kony.utils.ResourceManager;
import com.konylabs.android.KonyMain;
import com.konylabs.vm.Function;
import com.cathaypacific.IceMobile.R;
import com.squareup.timessquare.CalendarPickerView;
import com.squareup.timessquare.CalendarPickerView.OnDateSelectedListener;
import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class CalendarActivity extends Activity implements OnDateSelectedListener {
	private CalendarPickerView cal = null;
	private com.konylabs.vm.Function mServeRequest;
	private TextView lblTitle = null;
	private TextView lblDepartingOn = null;
	private TextView lblDepartingDate = null;
	private TextView lblReturningOn = null;
	private TextView lblReturningDate = null;
	private Button btnConfirm = null;
	private ImageView ivBack = null;
	private Locale locale = null;
	private String dateFormat = null;
	private String dateDisplayFormat = null;
	private String strAddDate = null;
	private boolean isSingleCalendar = false;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		String infoTxtConfirm = "";
		String infoTitle = "";
		String infoDepartingOn = "";
		String infoReturningOn = "";
		String infoMinDate = "";
		String infoMaxDate = "";
		String infoType = "";
		String infoDepartingDate = "";
		String infoReturningDate = "";
		String infoLocale = "";
		String infoAddDate = "";
		String infoDateFormat = "";
		Bundle extras = getIntent().getExtras();
		String info = extras.getString("info");
		mServeRequest = (Function) extras.get("callback");
		try {
			JSONObject infoJSON = new JSONObject(info);
			
			infoTxtConfirm = infoJSON.getString("txtConfirm");
			infoTitle = infoJSON.getString("title");
			infoMinDate = infoJSON.getString("minDate");
			infoMaxDate = infoJSON.getString("maxDate");
			infoDepartingOn = infoJSON.getString("txtDepartingOn");
			infoReturningOn = infoJSON.getString("txtReturningOn");
			infoType = infoJSON.getString("type");
			infoDepartingDate = infoJSON.getString("departureDate");
			infoReturningDate = infoJSON.getString("returningDate");
			infoLocale = infoJSON.getString("locale");
			infoAddDate = infoJSON.getString("txtAddDate");
			infoDateFormat = infoJSON.getString("dateformat");
		} catch (JSONException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		this.isSingleCalendar = (infoType.equals("oneway"));	
		if(isSingleCalendar) {
			setContentView(R.layout.activity_calendar_single);	
		}else {
			setContentView(R.layout.activity_calendar);
		}
		
		//Hide action bar
		getActionBar().hide();
		
		this.lblTitle = (TextView) findViewById(R.id.lblTitle);
		this.lblDepartingOn = (TextView) findViewById(R.id.lblDepartingOn);
		this.lblDepartingDate = (TextView) findViewById(R.id.lblDepartingDate);
		this.lblReturningOn = (TextView) findViewById(R.id.lblReturningOn);
		this.lblReturningDate = (TextView) findViewById(R.id.lblReturningDate);
		this.btnConfirm = (Button) findViewById(R.id.btnConfirm);
		this.ivBack = (ImageView) findViewById(R.id.ivBack);
		this.cal = (CalendarPickerView) findViewById(R.id.calendar_view);
		
		String language = "";
		String country = "";
		String[] localeParam = infoLocale.split("_");
		
		this.dateFormat = "yyyy-MM-dd";
		this.dateDisplayFormat = infoDateFormat;

		if(localeParam.length == 2) {
		language = localeParam[0];
		country = localeParam[1];
		} else if(localeParam.length == 1) {
			language = localeParam[0];
		}
		
		Locale locale = Locale.ENGLISH;
		if(language.equals("sc")) {	//Special handling for simplified Chinese
			locale = Locale.CHINA;
		}else {
			locale = new Locale(language, country);	
		}
		
		this.locale = locale;
		this.strAddDate = infoAddDate;
		this.lblTitle.setText(infoTitle);
		this.lblDepartingOn.setText(infoDepartingOn);
		this.lblReturningOn.setText(infoReturningOn);
		this.btnConfirm.setText(infoTxtConfirm);
		
		//Set Text Font
		this.btnConfirm.setTypeface(Typeface.createFromAsset(getAssets(),
                "fonts/AktivGrotesk-Light.ttf"));
		this.lblTitle.setTypeface(Typeface.createFromAsset(getAssets(),
                "fonts/AktivGrotesk-Light.ttf"));
		btnConfirm.setTextSize(16);
		
		int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10, getResources().getDisplayMetrics());
		AbsListView.LayoutParams params = new AbsListView.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
		//Add margin header
		LinearLayout llHeader = new LinearLayout(this);
		params.height = height;
	    llHeader.setLayoutParams(params);
	    llHeader.setBackgroundColor(getResources().getColor(R.color.calendar_widget_bg));
	    this.cal.addHeaderView(llHeader);
	    
	  //Add margin footer
  		LinearLayout llFooter = new LinearLayout(this);
  		llFooter.setLayoutParams(params);
  		llFooter.setBackgroundColor(getResources().getColor(R.color.calendar_widget_bg));
  	    this.cal.addFooterView(llFooter);
	    
//         Calendar lowerLimit = Calendar.getInstance(this.locale);
//	//      lowerLimit.add(Calendar.DATE,-1);
//	     lowerLimit.set(Calendar.HOUR_OF_DAY,0);
//	     lowerLimit.set(Calendar.MINUTE,0);
//	     lowerLimit.set(Calendar.SECOND,0);
//	     lowerLimit.set(Calendar.MILLISECOND,0);
//	     Date startDate = lowerLimit.getTime();
//	
//	     Calendar upperLimit = Calendar.getInstance(this.locale);
//	     upperLimit.add(Calendar.DATE,360);
//	     upperLimit.set(Calendar.HOUR_OF_DAY,0);
//	     upperLimit.set(Calendar.MINUTE,0);
//	     upperLimit.set(Calendar.SECOND,0);
//	     upperLimit.set(Calendar.MILLISECOND,0);
//	     Date endDate = upperLimit.getTime();
  	    
  	    Date startDate = parseDate(infoMinDate,this.dateFormat,this.locale);
  	    Date endDate = null;
  	    SimpleDateFormat sdf = new SimpleDateFormat(this.dateFormat, this.locale);
  	    Calendar c = Calendar.getInstance();
  	    try {
  	    	c.setTime(sdf.parse(infoMaxDate));
  	    } catch (ParseException e) {
  	    	e.printStackTrace();
  	    }
  	    c.add(Calendar.DATE, 1);
  	    endDate = c.getTime();
  	    
	     this.cal.setTypeface(ResourceManager.getWidgetTitleTypeFace(), ResourceManager.getWidgetTypeFace());
	     this.cal.setOnDateSelectedListener(this);
	     this.cal.init(startDate, endDate, this.locale)
	             .inMode(CalendarPickerView.SelectionMode.RANGE)
	             .withSelectedDates(null);
	     
	     //Assign Event Listeners
	     this.ivBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
	     });
	     
	     this.btnConfirm.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(btnConfirm.isEnabled()) {
					Handler mainHandler = new Handler(KonyMain.getAppContext().getMainLooper());
					Runnable myRunnable = new Runnable() {
					    @Override 
					    public void run() {
					    	try {
					    		String startDate = getStartDate();
								String endDate = getEndDate();
								String ret = startDate;
								if(!endDate.isEmpty())
									ret += "|" + endDate;
								mServeRequest.executeAsync(new Object[]{ret});
								finish();
							} catch (Exception e) {
								e.printStackTrace();
								throw new RuntimeException(e);
							}	
					    }
					};
					mainHandler.post(myRunnable);					
				}
			}
	     });
	     
	     if(isSingleCalendar) {
	    	 setSingleDate(infoDepartingDate);	 
	     }else {
	    	 setSelectedDateRange(infoDepartingDate, infoReturningDate);	 
	     }
	     
	     updateUIDate();
	}

	@Override
	public void onDateSelected(Date paramDate) {
		updateUIDate();
	}

	@Override
	public void onDateUnselected(Date paramDate) {
	}
	
	private void updateUIDate() {
		
		String startDate = getStartDate(this.dateDisplayFormat, this.locale);
		String endDate = getEndDate(this.dateDisplayFormat, this.locale);
		
		this.btnConfirm.setBackgroundResource(R.drawable.cta_background_active);
		this.btnConfirm.setTextColor(getResources().getColor(R.color.calendar_cfnbtn_text_active));
		this.btnConfirm.setEnabled(true);
		
		
		if(startDate.isEmpty()) {
			startDate = this.strAddDate;
			if(this.isSingleCalendar) {
				this.btnConfirm.setBackgroundResource(R.drawable.cta_background_inactive);
				this.btnConfirm.setTextColor(getResources().getColor(R.color.calendar_cfnbtn_text_inactive));
				this.btnConfirm.setEnabled(false);
			}
			this.lblDepartingOn.setAlpha((float) 0.3);
			this.lblDepartingDate.setAlpha((float) 0.3);
		}else {
			this.lblDepartingOn.setAlpha((float) 1);
			this.lblDepartingDate.setAlpha((float) 1);
		}
		if(endDate.isEmpty()) {
			endDate = this.strAddDate;
			this.lblReturningOn.setAlpha((float) 0.3);
			this.lblReturningDate.setAlpha((float) 0.3);
			if(!this.isSingleCalendar) {
				this.btnConfirm.setBackgroundResource(R.drawable.cta_background_inactive);
				this.btnConfirm.setTextColor(getResources().getColor(R.color.calendar_cfnbtn_text_inactive));
				this.btnConfirm.setEnabled(false);
			}
		}else {
			this.lblReturningOn.setAlpha((float) 1);
			this.lblReturningDate.setAlpha((float) 1);
		}
		
		this.lblDepartingDate.setText(startDate);
		this.lblReturningDate.setText(endDate);
	}
	
	public String getStartDate(String dateFormat, Locale locale) {
        if (this.cal != null) {
            List dates = this.cal.getSelectedDates();
            if ((dates != null) && (dates.size() > 0)) {
                return formatDate((Date)dates.get(0), dateFormat, locale);
            }
        }
        return "";
    }
	
	public String getStartDate() {
		return getStartDate(this.dateFormat,this.locale);
	}

    public String getEndDate(String dateFormat, Locale locale) {
        if (this.cal != null) {
        	List dates = this.cal.getSelectedDates();
        	if(dates !=null) {
        		if(dates.size() > 1 || this.cal.getIsSameDaySelected())
            		return formatDate((Date)dates.get(dates.size() - 1), dateFormat, locale);
        	}
        }
        return "";
    }
    
    public String getEndDate() {
    	return getEndDate(this.dateFormat,this.locale);
    }
    
    public Boolean setSingleDate(final String sDate){
	    Date s = parseDate(sDate,this.dateFormat,this.locale);
	    if (s != null) {
	        this.cal.setSingleDate(s);
	    }
        return Boolean.TRUE;
    }

	public Boolean setSelectedDateRange(final String start, final String end) {
        Date s = parseDate(start,this.dateFormat,this.locale);
        Date e = parseDate(end,this.dateFormat,this.locale);

        if (s != null) {
//            if ((e == null) || (e.before(s))) {
//                e = s;
//            }
            this.cal.setDateRange(s, e);
            return Boolean.TRUE;
        }else {
        	return Boolean.FALSE;
        }
    }
    
	private static Date parseDate(String s,String dateFormat, Locale locale) {
        try {
            return getDateFormat(dateFormat, locale).parse(s);
        }
        catch (ParseException localParseException) {
        }
        return null;
    }
	
    private static String formatDate(Date d, String dateFormat, Locale locale) {
        return getDateFormat(dateFormat,locale).format(d);
    }
    
    private static SimpleDateFormat getDateFormat(String dateFormat, Locale locale)
    {
        return new SimpleDateFormat(dateFormat,locale);
    }
}
