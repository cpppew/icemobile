package com.cathaypacific.icecalendar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.AbsListView.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.kony.utils.ResourceManager;
import com.konylabs.android.KonyMain;
import com.konylabs.api.ui.KonyCustomWidget;
import com.squareup.timessquare.CalendarPickerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CalendarWidget extends KonyCustomWidget implements CalendarPickerView.OnDateSelectedListener
{
    private static final long serialVersionUID = -5458656966350224558L;
    private ViewGroup mRootView = null;

    private CalendarPickerView cal = null;
    private static SimpleDateFormat _myDateFormat = null;
    private Handler _h;

    private com.konylabs.vm.Function mServeRequest;
    
    private int getResourceId(String name, String type)
    {
        return ResourceManager.getResourceId(name, type);
    }
    private void setContentView(int rLayoutId) {
        this.mRootView = ((ViewGroup) ResourceManager.inflateLayout(rLayoutId));
    }

    private static SimpleDateFormat getDateFormat()
    {
        if (_myDateFormat == null) {
            _myDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        }
        return _myDateFormat;
    }
    private static String formatDate(Date d) {
        return getDateFormat().format(d);
    }
    private static Date parseDate(String s) {
        try {
            return getDateFormat().parse(s);
        }
        catch (ParseException localParseException) {
        }
        return null;
    }

    public Boolean setSingleDate(final String sDate){
        this._h.post(new Runnable()
        {
            public void run()
            {
                Date s = CalendarWidget.parseDate(sDate);
                if (s != null) {
                    CalendarWidget.this.cal.setSingleDate(s);
                }
            }
        } );
        return Boolean.TRUE;
    }

	public Boolean setSelectedDateRange(final String start, final String end) {
        this._h.post(new Runnable()
        {
            public void run()
            {
                Date s = CalendarWidget.parseDate(start);
                Date e = CalendarWidget.parseDate(end);

                if (s != null) {
                    if ((e == null) || (e.before(s))) {
                        e = s;
                    }
                    CalendarWidget.this.cal.setDateRange(s, e);
                }
            }
        } );
        return Boolean.TRUE;
    }
    public String getStartDate() {
        if (this.cal != null) {
            List dates = this.cal.getSelectedDates();
            if ((dates != null) && (dates.size() > 0)) {
                return formatDate((Date)dates.get(0));
            }
        }
        return "";
    }

    public String getEndDate() {
        if (this.cal != null) {
        	List dates = this.cal.getSelectedDates();
        	if(dates !=null) {
        		if(dates.size() > 1 || this.cal.getIsSameDaySelected())
            		return formatDate((Date)dates.get(dates.size() - 1));
        	}
        }
        return "";
    }
    
    public void bridge (com.konylabs.vm.Function callback) {
    	mServeRequest = callback;
    }

    public View onCreateView(Context arg0)
    {
        this._h = new Handler();
        ResourceManager.setContext(arg0);
        setContentView(getResourceId("calendar", "layout"));

        Calendar lowerLimit = Calendar.getInstance();
//        lowerLimit.add(Calendar.DATE,-1);
        lowerLimit.set(Calendar.HOUR_OF_DAY,0);
        lowerLimit.set(Calendar.MINUTE,0);
        lowerLimit.set(Calendar.SECOND,0);
        lowerLimit.set(Calendar.MILLISECOND,0);
        Date startDate = lowerLimit.getTime();

        Calendar upperLimit = Calendar.getInstance();
//        upperLimit.add(Calendar.DATE,360);
        upperLimit.add(Calendar.MONTH,3);
        upperLimit.set(Calendar.HOUR_OF_DAY,0);
        upperLimit.set(Calendar.MINUTE,0);
        upperLimit.set(Calendar.SECOND,0);
        upperLimit.set(Calendar.MILLISECOND,0);

        this.cal = ((CalendarPickerView)this.mRootView.findViewById(getResourceId("calendar_view", "id")));

        Collection dd = null;

        this.cal.setTypeface(ResourceManager.getWidgetTitleTypeFace(), ResourceManager.getWidgetTypeFace());
        this.cal.init(startDate, upperLimit.getTime(), Locale.CANADA)
                .inMode(CalendarPickerView.SelectionMode.RANGE)
                .withSelectedDates(dd);
        this.cal.setOnDateSelectedListener(this);
        
//        this.cal.fixDimens(LayoutParams.MATCH_PARENT, this.cal.getTotalHeightofListView());
        Log.w("TOTALHEIGHT" , String.valueOf(this.cal.getTotalHeightofListView()));
        
        return this.mRootView;
    }

    
    
    public void onDestroyView(View arg0)
    {
        this.mRootView.removeAllViews();
        this.mRootView = null;
    }

    public void setHeight(int arg0)
    {
    }

    public void setWidth(int arg0)
    {
    }
    
    private void constructDateInfo() {
    	String startDate = getStartDate();
		String endDate = getEndDate();
		String ret = startDate;
		if(!endDate.isEmpty())
			ret += "|" + endDate;
        try {
			mServeRequest.execute(new Object[]{ret});
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
    }
    
	@Override
	public void onDateSelected(Date paramDate) {
		final Activity activity = KonyMain.getActivityContext();
        Intent intent = new Intent(activity, CalendarActivity.class);
        activity.startActivity(intent);
		this.constructDateInfo();
	}
	@Override
	public void onDateUnselected(Date paramDate) {
		
	}
}