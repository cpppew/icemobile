package com.cathaypacific.icecalendar;

import android.app.Activity;
import android.content.Intent;
import com.kony.utils.ResourceManager;
import com.konylabs.android.KonyMain;

public class CalendarUtil {
	public static void showcalendar (java.lang.String info,com.konylabs.vm.Function callback) {
		final Activity activity = KonyMain.getActivityContext();
        Intent intent = new Intent(activity, CalendarActivity.class);
        intent.putExtra("callback", callback);
        intent.putExtra("info", info);
        ResourceManager.setContext(KonyMain.getAppContext());
        activity.startActivity(intent);
	}
}