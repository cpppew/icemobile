package com.cathaypacific.appindex;

import android.app.Activity;
import com.konylabs.android.KonyMain;
import android.net.Uri;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

public class AppIndexUtil {
    private static GoogleApiClient mClient;
    
	public static void init() {
		final Activity activity = KonyMain.getActivityContext();
		mClient = new GoogleApiClient.Builder(activity).addApi(AppIndex.API).build();
	}
	public static void startIndex(String app, String web, String title) {
		Uri uri_web = Uri.parse(web);
		Uri uri_app = Uri.parse(app);
		// Connect your client
        mClient.connect();
        // Construct the Action performed by the user
        Action viewAction = Action.newAction(Action.TYPE_VIEW, title, uri_web, uri_app);
        // Call the App Indexing API start method after the view has completely rendered
        AppIndex.AppIndexApi.start(mClient, viewAction);	
	}
	public static void stopIndex(String app, String web, String title) {
		Uri uri_web = Uri.parse(web);
		Uri uri_app = Uri.parse(app);
		// Call end() and disconnect the client
		Action viewAction = Action.newAction(Action.TYPE_VIEW, title, uri_web, uri_app);
        AppIndex.AppIndexApi.end(mClient, viewAction);
        mClient.disconnect();
	}
}
