package com.cathaypacific.IceMobile;

import com.konylabs.android.KonyMain;




import android.os.Bundle;

public class IceMobileP2S2 extends KonyMain {
	private static IceMobileP2S2 context;
    public void onCreate(Bundle savedInstanceState) {
		context = this;
        super.onCreate(savedInstanceState);
    }
		
	public static IceMobileP2S2 getActivityContext() {
		return context;
	}
	
	public int getAppSourceLocation(){
		return 1;
	}
	
	
	
}
