package com.squareup.timessquare;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.kony.utils.ResourceManager;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static java.util.Calendar.DATE;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.DAY_OF_WEEK;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.YEAR;

public class CalendarPickerView extends ListView
{
    private final MonthAdapter adapter = new MonthAdapter();
    private final List<List<List<MonthCellDescriptor>>> cells = new ArrayList();
    final MonthView.Listener listener = new CellClickedListener();
    final List<MonthDescriptor> months = new ArrayList<MonthDescriptor>();
    final List<MonthCellDescriptor> selectedCells = new ArrayList<MonthCellDescriptor>();
    final List<MonthCellDescriptor> highlightedCells = new ArrayList<MonthCellDescriptor>();
    final List<Calendar> selectedCals = new ArrayList<Calendar>();
    final List<Calendar> highlightedCals = new ArrayList<Calendar>();
    private Locale locale;
    private DateFormat monthNameFormat;
    private DateFormat weekdayNameFormat;
    private DateFormat fullDateFormat;
    private Calendar minCal;
    private Calendar maxCal;
    private Calendar monthCounter;
    private boolean displayOnly;
    SelectionMode selectionMode;
    Calendar today;
    private int dividerColor;
    private int dayBackgroundResId;
    private int dayTextColorResId;
    private int titleTextColor;
    private boolean displayHeader;
    private int headerTextColor;
    private Typeface titleTypeface;
    private Typeface dateTypeface;
    private OnDateSelectedListener dateListener;
    private DateSelectableFilter dateConfiguredListener;
    private OnInvalidDateSelectedListener invalidDateListener = new DefaultOnInvalidDateSelectedListener();
    private boolean isSameDateSelected;
    
    private String month_name_format = "MMMM yyyy";
    private String day_name_format = "EEE";
    
    public CalendarPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.obtainStyledAttributes(attrs, ResourceManager.getStyleableResourceIds("CalendarPickerView"));

        int bg = a.getColor(ResourceManager.getResourceId("CalendarPickerView_android_background", "styleable"),
                ResourceManager.getResourceColor("calendar_bg"));

        this.dividerColor = a.getColor(ResourceManager.getResourceId("CalendarPickerView_dividerColor", "styleable"),
                ResourceManager.getResourceColor("calendar_divider"));

        this.dayBackgroundResId = a.getResourceId(ResourceManager.getResourceId("CalendarPickerView_dayBackground", "styleable"),
                ResourceManager.getResourceId("calendar_bg_selector", "drawable"));

        this.dayTextColorResId = a.getResourceId(ResourceManager.getResourceId("CalendarPickerView_dayTextColor", "styleable"),
                ResourceManager.getResourceId("calendar_text_selector", "drawable"));
        this.titleTextColor = a.getColor(ResourceManager.getResourceId("CalendarPickerView_titleTextColor", "styleable"),
                ResourceManager.getResourceColor("calendar_text_title"));
        this.headerTextColor = a.getColor(ResourceManager.getResourceId("CalendarPickerView_titleWeekTextColor", "styleable"),
                ResourceManager.getResourceColor("calendar_text_week_title"));
        this.displayHeader = a.getBoolean(ResourceManager.getResourceId("CalendarPickerView_displayHeader", "styleable"), true);
//        this.headerTextColor = a.getColor(ResourceManager.getResourceId("CalendarPickerView_headerTextColor", "styleable"), ResourceManager.getResourceColor("calendar_text_title"));
        a.recycle();

        Log.d(VIEW_LOG_TAG,"bg-color:"+this.dayBackgroundResId);

        setDivider(null);
        setDividerHeight(0);
        setBackgroundColor(bg);
        setCacheColorHint(bg);
        this.locale = Locale.getDefault();
        this.today = Calendar.getInstance(this.locale);
        this.minCal = Calendar.getInstance(this.locale);
        this.maxCal = Calendar.getInstance(this.locale);
        this.monthCounter = Calendar.getInstance(this.locale);
        this.monthNameFormat = new SimpleDateFormat(month_name_format, this.locale);
        this.weekdayNameFormat = new SimpleDateFormat(day_name_format, this.locale);
        this.fullDateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM, this.locale);

        if (isInEditMode()) {
            Calendar nextYear = Calendar.getInstance(this.locale);
            nextYear.add(Calendar.YEAR, 1);

            init(new Date(), nextYear.getTime())
                    .withSelectedDate(new Date());
        }
    }

    public FluentInitializer init(Date minDate, Date maxDate, Locale locale)
    {
        if ((minDate == null) || (maxDate == null)) {
            throw new IllegalArgumentException(
                    "minDate and maxDate must be non-null.  " + dbg(minDate, maxDate));
        }
        if (minDate.after(maxDate)) {
            throw new IllegalArgumentException(
                    "minDate must be before maxDate.  " + dbg(minDate, maxDate));
        }
        if ((minDate.getTime() == 0L) || (maxDate.getTime() == 0L)) {
            throw new IllegalArgumentException(
                    "minDate and maxDate must be non-zero.  " + dbg(minDate, maxDate));
        }
        if (locale == null) {
            throw new IllegalArgumentException("Locale is null.");
        }

        this.locale = locale;
        this.today = Calendar.getInstance(locale);
        this.minCal = Calendar.getInstance(locale);
        this.maxCal = Calendar.getInstance(locale);
        this.monthCounter = Calendar.getInstance(locale);
        this.monthNameFormat =
                new SimpleDateFormat(month_name_format, locale);
        for (MonthDescriptor month : this.months) {
            month.setLabel(this.monthNameFormat.format(month.getDate()));
        }
        this.weekdayNameFormat =
                new SimpleDateFormat(day_name_format, locale);
        this.fullDateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM, locale);

        this.selectionMode = SelectionMode.SINGLE;

        this.selectedCals.clear();
        this.selectedCells.clear();
        this.highlightedCals.clear();
        this.highlightedCells.clear();

        this.cells.clear();
        this.months.clear();
        this.minCal.setTime(minDate);
        this.maxCal.setTime(maxDate);
        setMidnight(this.minCal);
        setMidnight(this.maxCal);
        this.displayOnly = false;

        this.maxCal.add(Calendar.MINUTE, -1);

        this.monthCounter.setTime(this.minCal.getTime());
        int maxMonth = this.maxCal.get(Calendar.MONTH);
        int maxYear = this.maxCal.get(Calendar.YEAR);
        while (((this.monthCounter.get(Calendar.MONTH) <= maxMonth) ||
                (this.monthCounter.get(Calendar.YEAR) < maxYear)) && (
                this.monthCounter.get(Calendar.YEAR) < maxYear + 1)) {
            Date date = this.monthCounter.getTime();
            MonthDescriptor month =
                    new MonthDescriptor(this.monthCounter.get(Calendar.MONTH), this.monthCounter.get(Calendar.YEAR), date,
                            this.monthNameFormat.format(date));
            this.cells.add(getMonthCells(month, this.monthCounter));

            this.months.add(month);
            this.monthCounter.add(Calendar.MONTH, 1);
        }

        validateAndUpdate();
        return new FluentInitializer();
    }

    public FluentInitializer init(Date minDate, Date maxDate)
    {
        return init(minDate, maxDate, Locale.getDefault());
    }

    private void validateAndUpdate()
    {
        if (getAdapter() == null) {
            setAdapter(this.adapter);
        }
        this.adapter.notifyDataSetChanged();
    }

    private void scrollToSelectedMonth(int selectedIndex) {
        scrollToSelectedMonth(selectedIndex, false);
    }

    private void scrollToSelectedMonth(final int selectedIndex, final boolean smoothScroll) {
        post(new Runnable()
        {
            public void run()
            {
                if (smoothScroll)
                    CalendarPickerView.this.smoothScrollToPosition(selectedIndex);
                else
                    CalendarPickerView.this.setSelection(selectedIndex);
            }
        });
    }

    private void scrollToSelectedDates()
    {

        Integer selectedIndex = null;
        Integer todayIndex = null;
        Calendar today = Calendar.getInstance(locale);
        for (int c = 0; c < months.size(); c++) {
            MonthDescriptor month = months.get(c);
            if (selectedIndex == null) {
                for (Calendar selectedCal : selectedCals) {
                    if (sameMonth(selectedCal, month)) {
                        selectedIndex = c;
                        break;
                    }
                }
                if (selectedIndex == null && todayIndex == null && sameMonth(today, month)) {
                    todayIndex = c;
                }
            }
        }
        if (selectedIndex != null) {
            scrollToSelectedMonth(selectedIndex);
        } else if (todayIndex != null) {
            scrollToSelectedMonth(todayIndex);
        }

    }

    public void fixDialogDimens()
    {
        getLayoutParams().height = getMeasuredHeight();
        getLayoutParams().width = getMeasuredWidth();

        post(new Runnable()
        {
            public void run() {
                CalendarPickerView.this.scrollToSelectedDates();
            }
        });
    }

    public void setTitleTypeface(Typeface titleTypeface)
    {
        this.titleTypeface = titleTypeface;
        validateAndUpdate();
    }

    public void setDateTypeface(Typeface dateTypeface)
    {
        this.dateTypeface = dateTypeface;
        validateAndUpdate();
    }
    
    public void setTypeface(Typeface titleTypeFace, Typeface typeface)
    {
        setTitleTypeface(titleTypeFace);
        setDateTypeface(typeface);
    }
   

    public void unfixDialogDimens()
    {
        getLayoutParams().height = LayoutParams.MATCH_PARENT;
        getLayoutParams().width = LayoutParams.MATCH_PARENT;
        requestLayout();
    }
    
    public void fixDimens(int width, int height)
    {
        getLayoutParams().height = height;
        getLayoutParams().width = width;
        requestLayout();
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (this.months.isEmpty()) {
            throw new IllegalStateException(
                    "Must have at least one month to display.  Did you forget to call init()?");
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public Date getSelectedDate() {
        return this.selectedCals.size() > 0 ? this.selectedCals.get(0).getTime() : null;
    }

    public List<Date> getSelectedDates() {

        List selectedDates = new ArrayList();
        for (MonthCellDescriptor cal : this.selectedCells) selectedDates.add(cal.getDate());
        Collections.sort(selectedDates);
        return selectedDates;
    }

    private static String dbg(Date minDate, Date maxDate)
    {
        return "minDate: " + minDate + "\nmaxDate: " + maxDate;
    }

    static void setMidnight(Calendar cal)
    {
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
    }

    public boolean selectDate(Date date)
    {
        return selectDate(date, false);
    }

    public boolean selectDate(Date date, boolean smoothScroll)
    {
        validateDate(date);

        MonthCellWithMonthIndex monthCellWithMonthIndex = getMonthCellWithIndexByDate(date);
        if ((monthCellWithMonthIndex == null) || (!isDateSelectable(date))) {
            return false;
        }
        boolean wasSelected = doSelectDate(date, monthCellWithMonthIndex.cell);
        if (wasSelected) {
            scrollToSelectedMonth(monthCellWithMonthIndex.monthIndex, smoothScroll);
        }
        return wasSelected;
    }

    private void validateDate(Date date) {
        if (date == null) {
            throw new IllegalArgumentException("Selected date must be non-null.");
        }
        if (date.getTime() == 0L) {
            throw new IllegalArgumentException("Selected date must be non-zero.  " + date);
        }
        if ((date.before(this.minCal.getTime())) || (date.after(this.maxCal.getTime())))
            throw new IllegalArgumentException(
                    String.format("SelectedDate must be between minDate and maxDate.%nminDate: %s%nmaxDate: %s%nselectedDate: %s", new Object[]{
                            this.minCal.getTime(), this.maxCal.getTime(), date}));
    }
    
    private boolean doSelectDate(Date date, MonthCellDescriptor cell)
    {
        Calendar newlySelectedCal = Calendar.getInstance(this.locale);
        newlySelectedCal.setTime(date);

        setMidnight(newlySelectedCal);

        for (MonthCellDescriptor selectedCell : this.selectedCells) {
            selectedCell.setRangeState(MonthCellDescriptor.RangeState.NONE);
        }


        switch (this.selectionMode) {
            case RANGE:
                if (this.selectedCals.size() > 1)
                {
                    clearOldSelections();
                } else if ((this.selectedCals.size() == 1) && (newlySelectedCal.before(this.selectedCals.get(0))))
                {
                    clearOldSelections();
                }

                break;
            case MULTIPLE:
                date = applyMultiSelect(date, newlySelectedCal);
                break;
            case SINGLE:
                clearOldSelections();
                break;
            default:
                throw new IllegalStateException("Unknown selectionMode " + this.selectionMode);
        }

        this.isSameDateSelected = false;
        if (date != null) {
            cell.setHighlighted(false);
            if (selectionMode == SelectionMode.SINGLE){
                selectedCells.add(cell);
                cell.setSelected(true);
                selectedCells.get(0).setRangeState(MonthCellDescriptor.RangeState.SINGLE);
            }else{

                if (selectedCells.size() == 0 ){
                    selectedCells.add(cell);
                    cell.setSelected(true);
                    selectedCells.get(0).setRangeState(MonthCellDescriptor.RangeState.FIRST);
                }
                else if (selectedCells.get(0).equals(cell)){
                    selectedCells.get(0).setSelected(true);
                    selectedCells.get(0).setRangeState(MonthCellDescriptor.RangeState.SAME_DAY);
                    this.isSameDateSelected = true;
                }else{
                    cell.setSelected(true);
                    cell.setRangeState(MonthCellDescriptor.RangeState.LAST);

                    selectedCells.add(cell);
                    Date start = selectedCells.get(0).getDate();
                    Date end = cell.getDate();
                    selectedCells.get(0).setRangeState(MonthCellDescriptor.RangeState.FIRST);

                    for (List<List<MonthCellDescriptor>> month : cells) {
                        for (List<MonthCellDescriptor> week : month) {
                            for (MonthCellDescriptor singleCell : week) {
                                if (singleCell.getDate().after(start)
                                        && singleCell.getDate().before(end)
                                        && singleCell.isSelectable()) {
                                    singleCell.setSelected(true);
                                    singleCell.setRangeState(MonthCellDescriptor.RangeState.MIDDLE);
                                    selectedCells.add(singleCell);
                                }
                            }
                        }
                    }
                }
            }
            selectedCals.add(newlySelectedCal);
        }

        validateAndUpdate();
        return date != null;
    }

    private void clearOldSelections() {
        for (MonthCellDescriptor selectedCell : this.selectedCells)
        {
            selectedCell.setSelected(false);
            selectedCell.setRangeState(MonthCellDescriptor.RangeState.NONE);//s.get(0).setRangeState(MonthCellDescriptor.RangeState.SINGLE);
        }

        this.selectedCells.clear();
        this.selectedCals.clear();
    }

    private Date applyMultiSelect(Date date, Calendar selectedCal) {
        for (MonthCellDescriptor selectedCell : this.selectedCells) {
            if (selectedCell.getDate().equals(date))
            {
                selectedCell.setSelected(false);
                this.selectedCells.remove(selectedCell);
                date = null;
                break;
            }
        }
        for (Calendar cal : this.selectedCals) {
            if (sameDate(cal, selectedCal)) {
                this.selectedCals.remove(cal);
                break;
            }
        }
        return date;
    }

    public void highlightDates(Collection<Date> dates) {
        for (Date date : dates) {
            validateDate(date);

            MonthCellWithMonthIndex monthCellWithMonthIndex = getMonthCellWithIndexByDate(date);
            if (monthCellWithMonthIndex != null) {
                Calendar newlyHighlightedCal = Calendar.getInstance();
                newlyHighlightedCal.setTime(date);
                MonthCellDescriptor cell = monthCellWithMonthIndex.cell;

                this.highlightedCells.add(cell);
                this.highlightedCals.add(newlyHighlightedCal);
                cell.setHighlighted(true);
            }
        }

        this.adapter.notifyDataSetChanged();
        setAdapter(this.adapter);
    }

    public boolean getIsSameDaySelected() {
    	return this.isSameDateSelected;
    }
    
    private MonthCellWithMonthIndex getMonthCellWithIndexByDate(Date date)
    {
        int index = 0;
        Calendar searchCal = Calendar.getInstance(locale);
        searchCal.setTime(date);
        Calendar actCal = Calendar.getInstance(locale);

        for (List<List<MonthCellDescriptor>> monthCells : cells) {
            for (List<MonthCellDescriptor> weekCells : monthCells) {
                for (MonthCellDescriptor actCell : weekCells) {
                    actCal.setTime(actCell.getDate());
                    if (sameDate(actCal, searchCal) && actCell.isSelectable()) {
                        return new MonthCellWithMonthIndex(actCell, index);
                    }
                }
            }
            index++;
        }
        return null;
    }

    List<List<MonthCellDescriptor>> getMonthCells(MonthDescriptor month, Calendar startCal)
    {
        Calendar cal = Calendar.getInstance(locale);
        cal.setTime(startCal.getTime());
        List<List<MonthCellDescriptor>> cells = new ArrayList<List<MonthCellDescriptor>>();
        cal.set(DAY_OF_MONTH, 1);
        int firstDayOfWeek = cal.get(DAY_OF_WEEK);
        int offset = cal.getFirstDayOfWeek() - firstDayOfWeek;
        if (offset > 0) {
            offset -= 7;
        }
        cal.add(Calendar.DATE, offset);

        Calendar minSelectedCal = minDate(selectedCals);
        Calendar maxSelectedCal = maxDate(selectedCals);

        while ((cal.get(MONTH) < month.getMonth() + 1 || cal.get(YEAR) < month.getYear()) //
                && cal.get(YEAR) <= month.getYear()) {
            List<MonthCellDescriptor> weekCells = new ArrayList<MonthCellDescriptor>();
            cells.add(weekCells);
            for (int c = 0; c < 7; c++) {
                Date date = cal.getTime();
                boolean isCurrentMonth = cal.get(MONTH) == month.getMonth();
                boolean isSelected = isCurrentMonth && containsDate(selectedCals, cal);
                boolean isSelectable =
                        isCurrentMonth && betweenDates(cal, minCal, maxCal) && isDateSelectable(date);
                boolean isToday = sameDate(cal, today);
                boolean isHighlighted = containsDate(highlightedCals, cal);
                int value = cal.get(DAY_OF_MONTH);

                MonthCellDescriptor.RangeState rangeState = MonthCellDescriptor.RangeState.NONE;
                if (selectedCals.size() > 1) {
                    if (sameDate(minSelectedCal, cal)) {
                        rangeState = MonthCellDescriptor.RangeState.FIRST;
                    } else if (sameDate(maxDate(selectedCals), cal)) {
                        rangeState = MonthCellDescriptor.RangeState.LAST;
                    } else if (betweenDates(cal, minSelectedCal, maxSelectedCal)) {
                        rangeState = MonthCellDescriptor.RangeState.MIDDLE;
                    }
                }

                weekCells.add(
                        new MonthCellDescriptor(date, isCurrentMonth, isSelectable, isSelected, isToday,
                                isHighlighted, value, rangeState));
                cal.add(DATE, 1);
            }
        }
        return cells;
    }

    private static boolean containsDate(List<Calendar> selectedCals, Calendar cal) {
        for (Calendar selectedCal : selectedCals) {
            if (sameDate(cal, selectedCal)) {
                return true;
            }
        }
        return false;
    }

    private static Calendar minDate(List<Calendar> selectedCals) {
        if ((selectedCals == null) || (selectedCals.size() == 0)) {
            return null;
        }
        Collections.sort(selectedCals);
        return selectedCals.get(0);
    }

    private static Calendar maxDate(List<Calendar> selectedCals) {
        if ((selectedCals == null) || (selectedCals.size() == 0)) {
            return null;
        }
        Collections.sort(selectedCals);
        return selectedCals.get(selectedCals.size() - 1);
    }

    private static boolean sameDate(Calendar cal, Calendar selectedDate) {
        return (cal.get(Calendar.MONTH) == selectedDate.get(Calendar.MONTH)) &&
                (cal.get(Calendar.YEAR) == selectedDate.get(Calendar.YEAR)) &&
                (cal.get(Calendar.DATE) == selectedDate.get(Calendar.DATE));
    }

    private static boolean betweenDates(Calendar cal, Calendar minCal, Calendar maxCal) {
        Date date = cal.getTime();
        return betweenDates(date, minCal, maxCal);
    }

    static boolean betweenDates(Date date, Calendar minCal, Calendar maxCal) {
        Date min = minCal.getTime();
        return ((date.equals(min)) || (date.after(min))) &&
                (date.before(maxCal.getTime()));
    }

    private static boolean sameMonth(Calendar cal, MonthDescriptor month) {
        return (cal.get(Calendar.MONTH) == month.getMonth()) && (cal.get(Calendar.YEAR) == month.getYear());
    }

    private boolean isDateSelectable(Date date) {
        return (this.dateConfiguredListener == null) || (this.dateConfiguredListener.isDateSelectable(date));
    }

    public void setOnDateSelectedListener(OnDateSelectedListener listener) {
        this.dateListener = listener;
    }

    public void setOnInvalidDateSelectedListener(OnInvalidDateSelectedListener listener)
    {
        this.invalidDateListener = listener;
    }

    public void setDateSelectableFilter(DateSelectableFilter listener)
    {
        this.dateConfiguredListener = listener;
    }

    public void setSingleDate(Date sDate){
        clearOldSelections();
        this.selectionMode = SelectionMode.SINGLE;
        
        if ((sDate.before(this.minCal.getTime())) || (sDate.after(this.maxCal.getTime()))) {
        	return;
        }	
        
        Calendar cal1 = Calendar.getInstance(this.locale);
        cal1.setTime(sDate);
        selectDate(cal1.getTime());

        scrollToSelectedDates();
        validateAndUpdate();
    }

    public void setDateRange(Date startDate, Date endDate)
    {
        clearOldSelections();
        this.selectionMode = SelectionMode.RANGE;
        
        if(startDate !=null) {
        	if ((startDate.before(this.minCal.getTime())) || (startDate.after(this.maxCal.getTime()))) {
            	return;
            }	
        }
        if(endDate !=null) {
        	if ((endDate.before(this.minCal.getTime())) || (endDate.after(this.maxCal.getTime()))) {
            	return;
            }	
        }
        
        Calendar calStart = Calendar.getInstance(this.locale);
        calStart.setTime(startDate);

        setMidnight(calStart);

        Calendar calEnd = Calendar.getInstance(this.locale);
        if(endDate != null) {
        	calEnd.setTime(endDate);
        	setMidnight(calEnd);
        }

        selectDate(calStart.getTime());
        if(endDate != null) {
        	selectDate(calEnd.getTime());
        }
        scrollToSelectedDates();
//
//        Log.e("CAL", calStart.toString());
//        Log.e("CAL", "===s:=" + this.selectedCells.size());
        validateAndUpdate();
    }

    private class CellClickedListener
            implements MonthView.Listener
    {
        private CellClickedListener()
        {
        }

        public void handleClick(MonthCellDescriptor cell)
        {
            Date clickedDate = cell.getDate();

            if ((!CalendarPickerView.betweenDates(clickedDate, CalendarPickerView.this.minCal, CalendarPickerView.this.maxCal)) || (!CalendarPickerView.this.isDateSelectable(clickedDate))) {
                if (CalendarPickerView.this.invalidDateListener != null)
                    CalendarPickerView.this.invalidDateListener.onInvalidDateSelected(clickedDate);
            }
            else {
                boolean wasSelected = CalendarPickerView.this.doSelectDate(clickedDate, cell);

                if (CalendarPickerView.this.dateListener != null)
                    if (wasSelected)
                        CalendarPickerView.this.dateListener.onDateSelected(clickedDate);
                    else
                        CalendarPickerView.this.dateListener.onDateUnselected(clickedDate);
            }
        }
    }

    public interface DateSelectableFilter
    {
        boolean isDateSelectable(Date paramDate);
    }

    private class DefaultOnInvalidDateSelectedListener
            implements CalendarPickerView.OnInvalidDateSelectedListener
    {
        private DefaultOnInvalidDateSelectedListener()
        {
        }

        public void onInvalidDateSelected(Date date)
        {
        }
    }

    public class FluentInitializer
    {

        public FluentInitializer inMode(CalendarPickerView.SelectionMode mode)
        {
            CalendarPickerView.this.selectionMode = mode;
            CalendarPickerView.this.clearOldSelections();
            CalendarPickerView.this.validateAndUpdate();
            return this;
        }

        public FluentInitializer withSelectedDate(Date selectedDates)
        {
            return withSelectedDates(Arrays.asList(selectedDates));
        }

        public FluentInitializer withSelectedDates(Collection<Date> selectedDates)
        {
            if ((CalendarPickerView.this.selectionMode == SelectionMode.SINGLE) && (selectedDates.size() > 1)) {
                throw new IllegalArgumentException("SINGLE mode can't be used with multiple selectedDates");
            }
            if (selectedDates != null) {
                for (Date date : selectedDates)
                    CalendarPickerView.this.selectDate(date);
            }
            else {
                CalendarPickerView.this.clearOldSelections();
            }
            CalendarPickerView.this.scrollToSelectedDates();

            CalendarPickerView.this.validateAndUpdate();
            return this;
        }

        public FluentInitializer withHighlightedDates(Collection<Date> dates) {
            CalendarPickerView.this.highlightDates(dates);
            return this;
        }

        public FluentInitializer withHighlightedDate(Date date) {
            return withHighlightedDates(Arrays.asList(date));
        }

        public FluentInitializer setShortWeekdays(String[] newShortWeekdays) {
            DateFormatSymbols symbols = new DateFormatSymbols(CalendarPickerView.this.locale);
            symbols.setShortWeekdays(newShortWeekdays);

            return this;
        }

        public FluentInitializer displayOnly() {
            CalendarPickerView.this.displayOnly = true;
            return this;
        }
    }

    private class MonthAdapter extends BaseAdapter
    {
        private final LayoutInflater inflater;

        private MonthAdapter()
        {
            this.inflater = LayoutInflater.from(CalendarPickerView.this.getContext());
        }

        public boolean isEnabled(int position)
        {
            return false;
        }

        public int getCount() {
            return CalendarPickerView.this.months.size();
        }

        public Object getItem(int position) {
            return CalendarPickerView.this.months.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            MonthView monthView = (MonthView)convertView;
            if (monthView == null)
            {
                monthView =
                        MonthView.create(parent, this.inflater, CalendarPickerView.this.weekdayNameFormat, CalendarPickerView.this.listener, CalendarPickerView.this.today, CalendarPickerView.this.dividerColor,
                                CalendarPickerView.this.dayBackgroundResId, CalendarPickerView.this.dayTextColorResId, CalendarPickerView.this.titleTextColor, CalendarPickerView.this.displayHeader,
                                CalendarPickerView.this.headerTextColor);
            }
            monthView.init(
                    CalendarPickerView.this.months.get(position),
                    (List)CalendarPickerView.this.cells.get(position),
                    CalendarPickerView.this.displayOnly, CalendarPickerView.this.titleTypeface,
                    CalendarPickerView.this.dateTypeface);
            return monthView;
        }
    }

    private static class MonthCellWithMonthIndex
    {
        public MonthCellDescriptor cell;
        public int monthIndex;

        public MonthCellWithMonthIndex(MonthCellDescriptor cell, int monthIndex)
        {
            this.cell = cell;
            this.monthIndex = monthIndex;
        }
    }

    public interface OnDateSelectedListener
    {
        void onDateSelected(Date paramDate);

        void onDateUnselected(Date paramDate);
    }

    public interface OnInvalidDateSelectedListener
    {
        void onInvalidDateSelected(Date paramDate);
    }

    public enum SelectionMode
    {
        SINGLE,

        MULTIPLE,

        RANGE
    }
    
    public int getTotalHeightofListView() {
        ListAdapter mAdapter = this.getAdapter();
        int totalHeight = 0;
        for (int i = 0; i < mAdapter.getCount(); i++) {
            View mView = mAdapter.getView(i, null, this);
            mView.measure(
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            totalHeight += mView.getMeasuredHeight();
        }
        return totalHeight + (this.getDividerHeight() * (mAdapter.getCount() - 1));
    }
    
}