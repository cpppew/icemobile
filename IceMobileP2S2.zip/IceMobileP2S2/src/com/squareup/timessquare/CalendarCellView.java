package com.squareup.timessquare;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;

import com.kony.utils.ResourceManager;

public class CalendarCellView extends TextView
{
    private static final int[] STATE_SELECTABLE = {
            ResourceManager.getResourceId("state_selectable", "attr") };

    private static final int[] STATE_CURRENT_MONTH = {
            ResourceManager.getResourceId("state_current_month", "attr") };

    private static final int[] STATE_TODAY = {
            ResourceManager.getResourceId("state_today", "attr") };

    private static final int[] STATE_HIGHLIGHTED = {
            ResourceManager.getResourceId("state_highlighted", "attr") };

    private static final int[] STATE_RANGE_SINGLE = {
            ResourceManager.getResourceId("state_range_single", "attr") };

    private static final int[] STATE_RANGE_FIRST = {
            ResourceManager.getResourceId("state_range_first", "attr") };

    private static final int[] STATE_RANGE_MIDDLE = {
            ResourceManager.getResourceId("state_range_middle", "attr") };

    private static final int[] STATE_RANGE_LAST = {
            ResourceManager.getResourceId("state_range_last", "attr") };

    private static final int[] STATE_RANGE_SAME_DAY = {
        ResourceManager.getResourceId("state_range_same_day", "attr") };
    
    private boolean isSelectable = false;
    private boolean isCurrentMonth = false;
    private boolean isToday = false;
    protected boolean isHighlighted = false;
    private MonthCellDescriptor.RangeState rangeState = MonthCellDescriptor.RangeState.NONE;

    @SuppressWarnings("UnusedDeclaration")
    public CalendarCellView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setSelectable(boolean isSelectable) {
        this.isSelectable = isSelectable;
        refreshDrawableState();
    }

    public void setCurrentMonth(boolean isCurrentMonth) {
        this.isCurrentMonth = isCurrentMonth;
        refreshDrawableState();
    }

    public void setToday(boolean isToday) {
        this.isToday = isToday;
        refreshDrawableState();
    }

    public void setRangeState(MonthCellDescriptor.RangeState rangeState) {
        this.rangeState = rangeState;
        refreshDrawableState();
    }

    public void setHighlighted(boolean highlighted) {
        isHighlighted = highlighted;
        refreshDrawableState();
    }

    @Override
    protected int[] onCreateDrawableState(int extraSpace) {
        final int[] drawableState = super.onCreateDrawableState(extraSpace + 5);


        if (isHighlighted) {
            mergeDrawableStates(drawableState, STATE_HIGHLIGHTED);
        }

        if(rangeState== MonthCellDescriptor.RangeState.SINGLE){
            mergeDrawableStates(drawableState, STATE_RANGE_SINGLE);
        }else if (rangeState == MonthCellDescriptor.RangeState.FIRST) {
            mergeDrawableStates(drawableState, STATE_RANGE_FIRST);
        } else if (rangeState == MonthCellDescriptor.RangeState.MIDDLE) {
            mergeDrawableStates(drawableState, STATE_RANGE_MIDDLE);
        } else if (rangeState == MonthCellDescriptor.RangeState.LAST) {
            mergeDrawableStates(drawableState, STATE_RANGE_LAST);
        } else if (rangeState == MonthCellDescriptor.RangeState.SAME_DAY) {
            mergeDrawableStates(drawableState, STATE_RANGE_SAME_DAY);
            
        }else{

            if (isSelectable) {
                mergeDrawableStates(drawableState, STATE_SELECTABLE);
            }

            if (isCurrentMonth) {
                mergeDrawableStates(drawableState, STATE_CURRENT_MONTH);
            }

            if (isToday) {
                mergeDrawableStates(drawableState, STATE_TODAY);
            }

        }

        return drawableState;
    }
}