package com.squareup.timessquare;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kony.utils.ResourceManager;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.List;

public class MonthView extends LinearLayout
{
    TextView title;
    CalendarGridView grid;
    private Listener listener;

    public static MonthView create(ViewGroup parent, LayoutInflater inflater, DateFormat weekdayNameFormat, Listener listener, Calendar today, int dividerColor, int dayBackgroundResId, int dayTextColor, int titleTextColor, boolean displayHeader, int headerTextColor)
    {
        final MonthView view = (MonthView)inflater.inflate(ResourceManager.getResourceId("month", "layout"), parent, false);

        view.setDividerColor(dividerColor);
        view.setDayTextColor(dayTextColor);
        view.setTitleTextColor(titleTextColor);
        view.setDisplayHeader(displayHeader);
        view.setHeaderTextColor(headerTextColor);

        if (dayBackgroundResId != 0) {
            view.setDayBackground(dayBackgroundResId);
        }

        int originalDayOfWeek = today.get(Calendar.DAY_OF_WEEK);

        int firstDayOfWeek = today.getFirstDayOfWeek();
        CalendarRowView headerRow = (CalendarRowView)view.grid.getChildAt(0);
        for (int offset = 0; offset < 7; offset++) {
            today.set(Calendar.DAY_OF_WEEK, firstDayOfWeek + offset);
            TextView textView = (TextView)headerRow.getChildAt(offset);
            textView.setText(weekdayNameFormat.format(today.getTime()));
        }
        today.set(Calendar.DAY_OF_WEEK, originalDayOfWeek);
        view.listener = listener;
        return view;
    }

    public MonthView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.title = ((TextView)findViewById(ResourceManager.getResourceId("title", "id")));
        this.grid = ((CalendarGridView)findViewById(ResourceManager.getResourceId("calendar_grid", "id")));
    }

    public void init(MonthDescriptor month, List<List<MonthCellDescriptor>> cells, boolean displayOnly, Typeface titleTypeface, Typeface dateTypeface)
    {
        title.setText(month.getLabel());

        final int numRows = cells.size();
        grid.setNumRows(numRows);
        
        if (titleTypeface != null) {
            title.setTypeface(titleTypeface);
        }
        if (dateTypeface != null) {
            grid.setTypeface(dateTypeface);
        }
        
        for (int i = 0; i < 6; i++) {
            CalendarRowView weekRow = (CalendarRowView) grid.getChildAt(i + 1);
            weekRow.setListener(listener);
            if (i < numRows) {
                weekRow.setVisibility(VISIBLE);
                List<MonthCellDescriptor> week = cells.get(i);
                for (int c = 0; c < week.size(); c++) {
                    MonthCellDescriptor cell = week.get(c);
                    CalendarCellView cellView = (CalendarCellView) weekRow.getChildAt(c);

                    String cellDate = Integer.toString(cell.getValue());
                    if (!cellView.getText().equals(cellDate)) {
                        cellView.setText(cellDate);
                    }
                    cellView.setEnabled(cell.isCurrentMonth());
                    cellView.setClickable(!displayOnly);

                    cellView.setSelectable(cell.isSelectable());
                    cellView.setSelected(cell.isSelected());
                    if(cell.isSelected()) {
                    	cellView.setTypeface(dateTypeface, Typeface.BOLD);
                    }else {
                    	cellView.setTypeface(dateTypeface, Typeface.NORMAL);
                    }
                    
                    cellView.setCurrentMonth(cell.isCurrentMonth());
                    cellView.setToday(cell.isToday());
                    cellView.setRangeState(cell.getRangeState());
                    cellView.setHighlighted(cell.isHighlighted());
                    cellView.setTag(cell);
                }
            } else {
                weekRow.setVisibility(GONE);
            }
        } 
    }

    public void setDividerColor(int color)
    {
        this.grid.setDividerColor(color);
    }

    public void setDayBackground(int resId) {
        this.grid.setDayBackground(resId);
    }

    public void setDayTextColor(int resId)
    {
        this.grid.setDayTextColor(resId);
    }

    public void setTitleTextColor(int color) {
        this.title.setTextColor(color);
    }

    public void setDisplayHeader(boolean displayHeader) {
        this.grid.setDisplayHeader(displayHeader);
    }

    public void setHeaderTextColor(int color) {
        this.grid.setHeaderTextColor(color);
    }

    public interface Listener
    {
        void handleClick(MonthCellDescriptor paramMonthCellDescriptor);
    }
}