package com.squareup.timessquare;

import com.kony.utils.ResourceManager;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import static android.view.View.MeasureSpec.AT_MOST;
import static android.view.View.MeasureSpec.EXACTLY;
import static android.view.View.MeasureSpec.makeMeasureSpec;

public class CalendarRowView extends ViewGroup
        implements View.OnClickListener
{
    protected boolean isHeaderRow;
    protected boolean isFirstRow;
    private MonthView.Listener listener;
    private int cellSize;

    public CalendarRowView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        child.setOnClickListener(this);
        super.addView(child, index, params);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
    	int width = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics());
        final int totalWidth = MeasureSpec.getSize(widthMeasureSpec) - width;
                
        cellSize = totalWidth / 7;
        int cellWidthSpec = makeMeasureSpec(cellSize, EXACTLY);
        int cellHeightSpec = isHeaderRow ? makeMeasureSpec(cellSize, AT_MOST) : cellWidthSpec;
        int rowHeight = 0;
        for (int c = 0, numChildren = getChildCount(); c < numChildren; c++) {
            final View child = getChildAt(c);
            child.measure(cellWidthSpec, cellHeightSpec);
            // The row height is the height of the tallest cell.
            if (child.getMeasuredHeight() > rowHeight) {
                rowHeight = child.getMeasuredHeight();
            }
        }
        final int widthWithPadding = totalWidth + getPaddingLeft() + getPaddingRight();
        final int heightWithPadding = rowHeight + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(widthWithPadding, heightWithPadding);

    }

    protected void onLayout(boolean changed, int left, int top, int right, int bottom)
    {

        int cellHeight = bottom - top;
        for (int c = 0, numChildren = getChildCount(); c < numChildren; c++) {
            final View child = getChildAt(c);
            child.layout(c * cellSize, 0, (c + 1) * cellSize, cellHeight);
        }
    }

    public void setIsHeaderRow(boolean isHeaderRow)
    {
        this.isHeaderRow = isHeaderRow;
    }
    
    public void setIsFirstRow(boolean isFirstRow)
    {
        this.isFirstRow = isFirstRow;
    }

    public void onClick(View v)
    {
        if (this.listener != null)
            this.listener.handleClick((MonthCellDescriptor)v.getTag());
    }

    public void setListener(MonthView.Listener listener)
    {
        this.listener = listener;
    }

    public void setCellBackground(int resId) {
        for (int i = 0; i < getChildCount(); i++)
            getChildAt(i).setBackgroundResource(resId);
    }

    public void setCellTextColor(int resId)
    {
        for (int i = 0; i < getChildCount(); i++)
            ((TextView)getChildAt(i)).setTextColor(resId /*getContext().getResources().getColor(resId)*/);
    }

    public void setCellTextColor(ColorStateList colors)
    {
        Log.d("View", "====setTextColor=" + colors.toString());
        for (int i = 0; i < getChildCount(); i++)
            ((TextView)getChildAt(i)).setTextColor(colors);
    }

    public void setTypeface(Typeface typeface)
    {
        for (int i = 0; i < getChildCount(); i++)
        	((TextView)getChildAt(i)).setTypeface(typeface);
    }
}