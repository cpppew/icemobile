package com.squareup.timessquare;

import java.util.Date;

class MonthCellDescriptor
{
    private final Date date;
    private final int value;
    private final boolean isCurrentMonth;
    private boolean isSelected;
    private final boolean isToday;
    private boolean isSelectable;
    private boolean isHighlighted;
    private RangeState rangeState;

    MonthCellDescriptor(Date date, boolean currentMonth, boolean selectable, boolean selected, boolean today, boolean highlighted, int value, RangeState rangeState)
    {
        this.date = date;
        this.isCurrentMonth = currentMonth;
        this.isSelectable = selectable;
        this.isHighlighted = highlighted;
        this.isSelected = selected;
        this.isToday = today;
        this.value = value;
        this.rangeState = rangeState;
    }

    public Date getDate() {
        return this.date;
    }

    public boolean isCurrentMonth() {
        return this.isCurrentMonth;
    }

    public boolean isSelectable() {
        return this.isSelectable;
    }

    public void setSelectable(boolean s) {
        this.isSelectable = s;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean selected) {
        this.isSelected = selected;
    }

    boolean isHighlighted() {
        return this.isHighlighted;
    }

    void setHighlighted(boolean highlighted) {
        this.isHighlighted = highlighted;
    }

    public boolean isToday() {
        return this.isToday;
    }

    public RangeState getRangeState() {
        return this.rangeState;
    }

    public void setRangeState(RangeState rangeState) {
        this.rangeState = rangeState;
    }

    public int getValue() {
        return this.value;
    }

    public String toString() {
        return "MonthCellDescriptor{date=" +
                this.date +
                ", value=" +
                this.value +
                ", isCurrentMonth=" +
                this.isCurrentMonth +
                ", isSelected=" +
                this.isSelected +
                ", isToday=" +
                this.isToday +
                ", isSelectable=" +
                this.isSelectable +
                ", isHighlighted=" +
                this.isHighlighted +
                ", rangeState=" +
                this.rangeState +
                '}';
    }

    public enum RangeState
    {
        NONE, SINGLE, FIRST, MIDDLE, LAST,SAME_DAY;
    }
}