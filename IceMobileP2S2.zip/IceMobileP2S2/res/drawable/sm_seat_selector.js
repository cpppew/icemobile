/**
 * Created by andyyeung on 20/5/14.
 */
var cSeatSelector = function(passengers, templateId, resultId, platform) {
    var SEAT_OCCUPIED = "O";
    var SEAT_AVAILABLE = "F";
    var that = {
        passengers: passengers,
        selectedSeatItem: {},
        activeSeatItem: null,
        platform: platform
    };
	
	 var HTML_TAG_CLASS = {
    	OVERLAY : "overlay",
    	OVERLAY_HIDDEN: "overlay-hidden"
    };
    
    that.updateNavPosition = function(index, isInited){
        $('.swiper-nav .active-nav').removeClass('active-nav');
        var activeNav = $('.swiper-nav .swiper-slide').eq(index).addClass('active-nav');
        that.navSwiper.clickedSlideIndex = index;
        if (that.selectedSeatItem[that.navSwiper.clickedSlideIndex]) {
            if (that.activeSeatItem) {
                that.activeSeatItem.deactivate();
            }
            that.activeSeatItem = that.selectedSeatItem[that.navSwiper.clickedSlideIndex];
            that.activeSeatItem.activate();
            if (that.panZoom) {
                var bBox = that.activeSeatItem.seatUI.getBBox();
                console.log("Active Seat Location " + bBox.x + ":" + bBox.y);
                that.panZoom.scrollTo(bBox.x, bBox.y);
            }
        } else {
            if (that.activeSeatItem) {
                that.activeSeatItem.deactivate();
            }
        }
        if(!isInited) {
        	if(isMMB){
        		if(passengers[index] && passengers[index].canSelectSeat){
        			$("."+HTML_TAG_CLASS.OVERLAY).addClass(HTML_TAG_CLASS.OVERLAY_HIDDEN);
        		} else{
        			$("."+HTML_TAG_CLASS.OVERLAY_HIDDEN).removeClass(HTML_TAG_CLASS.OVERLAY_HIDDEN);
        		}
        	}
	        if (!activeNav.hasClass('swiper-slide-visible')) {
	            if (activeNav.index()>that.navSwiper.activeIndex) {
	                var thumbsPerNav = Math.floor(that.navSwiper.width/activeNav.width())-1;
	                that.navSwiper.swipeTo(activeNav.index()-thumbsPerNav);
	            }
	            else {
	                that.navSwiper.swipeTo(activeNav.index());
	            }
	        }
        }
    }

    that.getCurrentPassengerLabel = function() {
        return "P" + (that.navSwiper.clickedSlideIndex + 1);
    }


    var generateUrl = function(index, seatNo, isExtraLegroom, isExitRow, isPriority, isInited, isBassinet, passengerId) {
        var url = "blank.html?";
        if (that.platform == "android") {
            url = "file:///android_asset/" + url;
        }
        var paraString = "seatIndex=" + index;
        paraString += "&";
        paraString += "seatNo=" + seatNo;
        paraString += "&";
        paraString += "isExtraLegroom=" + isExtraLegroom;
        paraString += "&";
        paraString += "isExitRow=" + isExitRow;
        paraString += "&";
        paraString += "isPriority=" + isPriority;
        paraString += "&";
        paraString += "isInited=" + isInited;
        paraString += "&";
        paraString += "isBassinet=" + isBassinet;
        paraString += "&";
        paraString += "passengerId=" + passengerId;
        url += paraString;
        return url;
    }

    that.setSelectedSeatNo = function(seatMapItem, isInited) {
        if (seatMapItem.status == SEAT_AVAILABLE && !seatMapItem.selected) {
            var allowAllocateSeat = true;
            var seatNo = seatMapItem.seatRow + seatMapItem.seatNo;
            var isExtraLegroom = seatMapItem.addon? (seatMapItem.addon.indexOf("X") >= 0): false;
            var isBassinet = seatMapItem.addon? (seatMapItem.addon.indexOf("B") >= 0): false;
            var isExitRow = seatMapItem.rowFlag? (seatMapItem.rowFlag.indexOf("X") >= 0): false;
            var allowEXL = that.passengers[that.navSwiper.clickedSlideIndex].isAllowExtraLegSeat;
            var allowBabyBassinet = (that.passengers[that.navSwiper.clickedSlideIndex].infantName &&  that.passengers[that.navSwiper.clickedSlideIndex].infantName !== null); 
            var isEXLPaid = that.passengers[that.navSwiper.clickedSlideIndex].isExtraLegSeatPaid;
            var passengerId = that.passengers[that.navSwiper.clickedSlideIndex].passengerId;
            if(!isInited && isExtraLegroom && !allowEXL) {
                allowAllocateSeat = false;
            }
            if(isMMB && !isInited && isBassinet && !allowBabyBassinet){
				allowAllocateSeat = false;
			}
            if(!isInited && !isExtraLegroom && isEXLPaid) {
                allowAllocateSeat = false;
            }

            if(allowAllocateSeat) {
                if (that.selectedSeatItem[that.navSwiper.clickedSlideIndex]) {
                    that.selectedSeatItem[that.navSwiper.clickedSlideIndex].deselect();
                }
                if (that.activeSeatItem) {
                    that.activeSeatItem.deactivate();
                }
                that.activeSeatItem = seatMapItem;
                that.selectedSeatItem[that.navSwiper.clickedSlideIndex] = seatMapItem;
                that.passengers[that.navSwiper.clickedSlideIndex].seatNo = seatNo;
                that.passengers[that.navSwiper.clickedSlideIndex].isExtraLegroom = isExtraLegroom;
                that.passengers[that.navSwiper.clickedSlideIndex].isExitRow = isExitRow;
                seatMapItem.selectFor(that.getCurrentPassengerLabel());
                seatMapItem.activate();
                console.log("Select seat " +  that.passengers[that.navSwiper.clickedSlideIndex].seatNo + " for passenger " + that.passengers[that.navSwiper.clickedSlideIndex].name);
            }
            //            // Advance to next seat
            //            if (that.navSwiper.clickedSlideIndex < that.passengers.length - 1) {
            //                that.updateNavPosition(that.navSwiper.clickedSlideIndex + 1);
            //            }
            var url = generateUrl(that.navSwiper.clickedSlideIndex, seatNo, isExtraLegroom, isExitRow, seatMapItem.isPriority, isInited, isBassinet, passengerId);
            console.log("Open URL " + url);
            window.location = url;
        }
    }

    that.getSelectedSeats = function() {

    }

    // Render passenger selector bar
    var templateString = $('#' + templateId)[0].innerHTML;
	console.log(templateString);
    var tempFn = doT.template(templateString);
    var resultText = tempFn({passengers: that.passengers});
    $('#' + resultId)[0].innerHTML = resultText;

    that.navSwiper = $('.swiper-nav').swiper({
        visibilityFullFit: true,
        slidesPerView:'auto',
        //Thumbnails Clicks
        onSlideClick: function(){
            that.updateNavPosition(that.navSwiper.clickedSlideIndex);
        }
    });
    that.updateNavPosition(0);

    return that;
}