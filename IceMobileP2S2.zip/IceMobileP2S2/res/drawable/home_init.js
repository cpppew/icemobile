var screenHeight = Math.max(document.documentElement.clientHeight, window.innerHeight) - 40;

if (isAndroid){
	screenHeight = (deviceHeight / window.devicePixelRatio) * 0.881;
	if (hasTravelAlert){
		screenHeight =  screenHeight - 27;
	}
} else {
    if (hasTravelAlert){
        screenHeight =  screenHeight - 25;
    }
}

var heightBanner = Math.round(screenHeight * 0.3);
var heightButtons = screenHeight - heightBanner;

document.getElementById("banner_container").style.height = "" + heightBanner + "px";
document.getElementById("buttons_container").style.height = ""  + heightButtons + "px";

