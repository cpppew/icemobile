/**
 * Created by andyyeung on 15/5/14.
 */
var cSeatMapRenderer = function(paper, width, bodyHeight, seatSelector, platform) {

    var that = {
        paper: paper,
        platform: platform,
        baseAssetPath: null,
        width: width,
        bodyHeight: bodyHeight,
        seatSelector: seatSelector,
        bgUI: null,
        itemRenderer: null,
        bgRenderer: null,
        indicatorRenderer: null,
        config: null,
        sizeCalculator: null,
        positioningStrategy: null,
        itemAlignmentStrategy: null,
        seats:{},
        seatMapData:null
    };
    if (that.platform == "android") {
        that.baseAssetPath = "file:///android_asset/";
    } else {
        that.baseAssetPath = "./";
    }


    var configureItemRenderer = function(cabin) {
        that.itemRenderer = {};
        that.itemRenderer.seat = {
            "F": cFirstClassSeatRenderer(paper, that),
            "J": cBusinessClassSeatRenderer(paper, that),
            "NJ": cNewBusinessClassSeatRenderer(paper, that),
            "Y": cEconomyClassAndRegionalSeatRenderer(paper, that)
        }
        that.itemRenderer.empty = cEmptyRenderer(paper, that);
        that.itemRenderer.galley = cGalleyRenderer(paper, that);
        that.itemRenderer.toilet = cToiletRenderer(paper, that);
        that.itemRenderer.exit = cExitRenderer(paper, that);
        that.itemRenderer.aisle = cAisleRenderer(paper, that);
    }

	var updateConfiguration = function(blocks) {
        var itemMaxWidth = 0;
        var ECON_ADDON_RATIO = 0.61;
        var ECON_RATIO = 1.18;
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i];
            for (var j = 0; j < block.rows.length; j++) {
                var itemWidth = Math.floor(width * (1 - that.config.sideMargin * 2) / block.columnSize);
                if(itemWidth > itemMaxWidth) {
                    itemMaxWidth = itemWidth;
                }
            }
        }
        var itemMaxHeight = itemMaxWidth / ECON_ADDON_RATIO;
        var itemNormalHeight = itemMaxWidth / ECON_RATIO;
        that.config.rowSpacing = itemMaxHeight - itemNormalHeight;
    };

    var configure = function(cabin, isUpperDeck, blocks) {
        that.config = SEAT_MAP_CONFIGURATION[cabin];
        if (isUpperDeck) that.config = SEAT_MAP_CONFIGURATION["Upper" + cabin];
		if(cabin === "Y") {
            updateConfiguration(blocks);
        }
        configureItemRenderer(cabin);
        if (cabin === "F") {
            that.bgRenderer = cNoseRenderer(that.config, that.paper, that.baseAssetPath);
            that.sizeCalculator = cNoseSizeCalculator(that.config, that.itemRenderer);
            that.positioningStrategy = cCurvedPositioningStrategy(that.config, that.width, that.height);
            that.indicatorRenderer = cTopDownIndicatorRenderer(that.config, that.paper, that.width, that.height);
        } else {
            that.bgRenderer = cBodyRenderer(that.config, that.paper, that.baseAssetPath);
            that.sizeCalculator = cBodySizeCalculator(that.config, that.itemRenderer);
            that.positioningStrategy = cUniformPositioningStrategy(that.config, that.width, that.height);
            that.indicatorRenderer = cBlockIndicatorRenderer(that.config, that.paper, that.width, that.height);
        }
    };

    var configurePositioningAndAlignmentStrategy = function(cabin, offsetX, offsetY, metrics) {
        if (cabin === "F") {
            that.positioningStrategy = cCurvedPositioningStrategy(that.config, offsetX, offsetY, that.width, metrics.height);
            that.itemAlignmentStrategy = cNoseItemAlignmentStrategy(that.config, offsetX, offsetY, that.width, metrics.height);
        } else {
            that.positioningStrategy = cUniformPositioningStrategy(that.config, offsetX, offsetY, that.width, metrics.height);
            that.itemAlignmentStrategy = cBodyItemAlignmentStrategy(that.config, offsetX, offsetY, that.width, metrics.height);
        }
    }


    that.getSeat = function(seatLabel) {
        var seatRow = seatLabel.substring(0, seatLabel.length - 1);
        var seatNo = seatLabel.substring(seatLabel.length - 1);
        if(that.seats[seatRow] && that.seats[seatRow][seatNo]) {
        	return that.seats[seatRow][seatNo];
        }else {
        	return null;
        }
    }

    var registerSeat = function(seatMapItem) {
        if (!that.seats[seatMapItem.seatRow]) {
            that.seats[seatMapItem.seatRow] = {};
        }
        that.seats[seatMapItem.seatRow][seatMapItem.seatNo] = seatMapItem;
    }

    var getVisibleSeats = function(x1, y1, x2, y2) {
        console.log("Calculate visible Seat");
        var visibleSeats = [];
        for (var seatRow in that.seats) {
            var row = that.seats[seatRow];
            var visibleRow = [];
            for (var seatNo in row) {
                var seat = row[seatNo];
                if (seat.boundY + seat.boundHeight < y1 || seat.boundY > y2) break;
                if (seat.boundX + seat.boundWidth < x1 || seat.boundX > x2) continue;
                visibleRow.push(seat);
            }
            if (visibleRow.length > 0) visibleSeats.push(visibleRow);
        }
        return visibleSeats;
    };

    that.showSeatIndicator = function(x1, y1, x2, y2) {
        var visibleSeats = getVisibleSeats(x1, y1, x2, y2);
        that.indicatorRenderer.showSeatIndicator(x1, y1, x2, y2, visibleSeats);
    }

    that.hideSeatIndicator = function() {
        that.indicatorRenderer.hideSeatIndicator();
    }

    var calculateColWidthPortion = function(row) {
        var colSize = 0;
        for (var i = 0; i < row.items.length; i++) {
            var item = row.items[i];
            var span = item.span;
            var widthRatio = item.widthRatio;
            if (!widthRatio) widthRatio = 1;
            if (item.type == "seat") widthRatio = that.config.seatWidthRatio;
            if (!span) span = 1;
            colSize += span * widthRatio;
        }
        return colSize;
    };

    that.drawRow = function(y, seatType, columnSize, rows, rowIndex) {
        var row = rows[rowIndex];
        var colSize = calculateColWidthPortion(row);
        var itemWidth = that.positioningStrategy.getInnerWidth(y) / colSize;
        var x = that.positioningStrategy.getLeftBound(y);
      	//that.paper.rect(x, y, itemWidth * colSize, row.rowHeight, 0);

        var preItem;
        
        for (var i = 0; i < row.items.length; i++) {
            var item = row.items[i];
            var itemRenderer;
            if (item.type == "seat") {
                itemRenderer = that.itemRenderer[item.type][seatType];
            } else {
                itemRenderer = that.itemRenderer[item.type];
            }

            if (!itemRenderer) {
                console.log("Undefined render for type " + item.type + ":" + seatType);
                continue;
            }
            var span = item.span? item.span: 1;
            var widthRatio = 1;
            if (item.type == "seat") {
                widthRatio = that.config.seatWidthRatio;
            }
            var seatMapItem = {
                type: item.type,
                seatRow: row.seatRow,
                boundX: x,
                boundY: y,
                boundWidth: itemWidth * span * widthRatio,
                boundHeight: row.rowHeight,
                span: span
            };

            //itemRenderer.paper.rect(seatMapItem.boundX, seatMapItem.boundY, seatMapItem.boundWidth, seatMapItem.boundHeight, 0);
            //itemRenderer.paper.rect(seatMapItem.boundX, seatMapItem.boundY, seatMapItem.boundWidth, seatMapItem.boundHeight, 0);
            
            //for business class and first class, need to set direction for each item
            if (seatMapItem.type == "seat") {
                seatMapItem.seatType = seatType;
                seatMapItem.isPriority = item.priority;
                seatMapItem.seatNo = item.seatNo;
                seatMapItem.status = item.status;
                seatMapItem.addon = item.addon;
                seatMapItem.rowFlag = item.rowFlag;

            	changeDirection(i, row.items.length, seatType, preItem, seatMapItem);
            	preItem = seatMapItem;
            }
            itemRenderer.calculateItemSize(seatMapItem);
            that.itemAlignmentStrategy.alignItem(seatMapItem, row, i);
            seatMapItem.rotationAngle = that.itemAlignmentStrategy.getRotationAngle(seatMapItem, rows, rowIndex, i);
            itemRenderer.render(seatMapItem);
            // Register seatmap item
            if (seatMapItem.seatRow && seatMapItem.seatNo) {
               registerSeat(seatMapItem);
            }
            x += seatMapItem.boundWidth;
        }
        return row.rowHeight;
    };
    
    var changeDirection = function(index, totalItem, seatType, preItem, currentItem) {
    	if(seatType == "J" || seatType == "NJ") {
    		if(index == 0) {
	    		currentItem.isLeft = true;
	    	}else if(index == totalItem - 1){
	    		currentItem.isLeft = false;
	    	}else if(preItem == undefined){
	    		currentItem.isLeft = false;
	    	}else {
	    		if(preItem.isLeft) {
		    		currentItem.isLeft = false;
		    	}else {
		    		currentItem.isLeft = true;
		    	}
	    	}
    	} else if (seatType == "F") {
            if (index == 0) {
                currentItem.isLeft = true;
            } else {
                currentItem.isLeft = false;
            }
        }
    }


    that.drawBlock = function(y, seatType, seatBlock) {
        var blockHeight = 0;
        for (var i = 0; i < seatBlock.rows.length; i++) {
            var rowHeight = that.drawRow(y + blockHeight, seatType, seatBlock.columnSize, seatBlock.rows, i);
            blockHeight += rowHeight;
            blockHeight += that.itemAlignmentStrategy.getRowSpacing(seatBlock.rows[i], seatBlock.rows[i + 1]);
          //  blockHeight += that.config.rowSpacing;
        }
        return blockHeight;
    };


    var partitionBlocksByLabel = function(blocks) {
        var blockPartitions = [];
        var currentBlock = [];
        for (var i = 0; i < blocks.length; i++) {
            if (i > 0 && blocks[i].blockLabel) {
                blockPartitions.push(currentBlock);
                currentBlock = [];
            }
            currentBlock.push(blocks[i]);
        }
        blockPartitions.push(currentBlock);
        return blockPartitions;
    };

    var drawBlockPartitionLabel = function(y, blocks, requireSeperator) {
        if (blocks[0].blockLabel) {
            var label = that.paper.text(that.width / 2, y + 50, blocks[0].blockLabel).attr({"font-size": 20, "font-family": "Aktiv Grotesk", "font-weight": "Light", fill: "#666"});
            if (requireSeperator) {
                var seperateLinePath = "M0," + (y + 10) + "L" + (that.width) + "," + (y + 10);
                that.paper.path(seperateLinePath).attr({stroke: "#EEE", "stroke-dasharray": "-", "stroke-width": 1});
            }
            return label.getBBox().height + 70;
        } else {
            return 20;
        }
    };

    var isUpperDeck = function(blocks) {
        return blocks[0].upperDeck;
    };

    that.render = function(seatMapData) {
        that.seatMapData = seatMapData;
        var blockPartitions = partitionBlocksByLabel(seatMapData.blocks);
        var y = 0, blockStartY, bgHeights = [];
        for (var j = 0; j < blockPartitions.length; j++) {
            configure(seatMapData.cabin, isUpperDeck(blockPartitions[j]), blockPartitions[j]);
            // Draw label if provided
            y += drawBlockPartitionLabel(y, blockPartitions[j], j > 0);
            blockStartY = y;
            // Calculate size of background
            var metrics = that.sizeCalculator.calculate(that.width, seatMapData.seatType, blockPartitions[j]);
            // Draw Aircraft background
            var bgHeight = Math.max(metrics.height, that.bodyHeight);
            that.bgUI = that.bgRenderer.render(0, y, that.width, bgHeight);
            bgHeights.push(that.bgUI.getBBox().height);
            y = blockStartY + bgHeights[j];
        }
        y = 0;
        for (var j = 0; j < blockPartitions.length; j++) {
            configure(seatMapData.cabin, isUpperDeck(blockPartitions[j]), blockPartitions[j]);
            // Draw label if provided
            y += drawBlockPartitionLabel(y, blockPartitions[j], j > 0);
            blockStartY = y;
            // Calculate size of background
            var metrics = that.sizeCalculator.calculate(that.width, seatMapData.seatType, blockPartitions[j]);
            // Configure item position strategy
            configurePositioningAndAlignmentStrategy(seatMapData.cabin, 0, y, metrics);
            y += metrics.topPadding;
            for (var i = 0; i < blockPartitions[j].length; i++) {
                var blockHeight = that.drawBlock(y, seatMapData.seatType, blockPartitions[j][i]);
                y += blockHeight;
            }
            y = blockStartY + bgHeights[j];
        }
        that.height = y;
        that.showSeatIndicator(0, 0, paper.width, paper.height);
        return that.height;
    };

    return that;
}



