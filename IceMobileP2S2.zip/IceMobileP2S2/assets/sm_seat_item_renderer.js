/**
 * Created by andyyeung on 14/5/14.
 */
var cBaseRenderer = function(paper, mapRenderer) {
    var that = {
        paper:paper,
        mapRenderer: mapRenderer,
        baseAssetPath: mapRenderer.baseAssetPath
    }

    that.rightAlign = function(seatMapItem) {
        seatMapItem.x = seatMapItem.boundX + (seatMapItem.boundWidth - seatMapItem.width);
    }

    that.centerAlign = function(seatMapItem) {
        seatMapItem.x = seatMapItem.boundX + (seatMapItem.boundWidth - seatMapItem.width) / 2;
    }

    that.leftAlign = function(seatMapItem) {
        seatMapItem.x = seatMapItem.boundX;
    }

    that.bottomAlign = function(seatMapItem) {
        seatMapItem.y = seatMapItem.boundY + (seatMapItem.boundHeight - seatMapItem.height);
    }

    that.middleAlign = function(seatMapItem) {
        seatMapItem.y = seatMapItem.boundY + (seatMapItem.boundHeight - seatMapItem.height) / 2;
    }

    that.topAlign = function(seatMapItem) {
        seatMapItem.y = seatMapItem.boundY;
    }

    return that;
};

var cSeatPath = function() {
	
	var that = {};


    that.OLD_BUSINESS_LEFT_SEAT = {
        path: "M0,138.538l54.41-6.439L184.203,0.199l19.304,15.839v74L57.938,239.076L0,182.038V138.538z",
        width: 206.878,
        height: 241.004
    };

    that.OLD_BUSINESS_RIGHT_SEAT = {
        path: "M204.439,237.502h-59.5L3.744,91.002v-87l27.195,1.997l120.276,119.878l53.224,16.459V237.502z",
        width: 206.878,
        height: 241.004
    };

    that.NEW_BUSINESS_LEFT_SEAT = {
        path: "M3.594,1h72.588l124.953,205.229l-82,44.917l-38.063-63.993l-77.957-0.5L3.594,1z",
        width: 209.27,
        height: 258.304
    };

    that.NEW_BUSINESS_RIGHT_SEAT = {
        path: "M205.677,184.652l-75.042,0.117l-44.5,66.376l-79-44.917L128.199,1h77.478V184.652z",
        width: 209.27,
        height:258.304
    };

    that.FIRST_CLASS_SEAT = {
        path: "M117.879,3l95.899,260.098l-67.557,25.538l-6,98.907l-67.134,26.653L3,383.298V279.764l56.555-262L117.879,3z",
        width: 216.777,
        height: 417.195
    };

    that.FIRST_CLASS_MIDDLE_SEAT = {
        path: "M160.214,364.279h0.028l-70.09,53.309l-44.184-8.981l-42.431-118.3H3.536l16.773-212.19h-0.022L46.262,3.672l53.04,20.438L160.214,364.279L160.214,364.279z",
        width: 163.243,
        height: 420.588
    };

	return that;
	
};

var cSeatSelectionControl = function(seatItem, seatMapRenderer, itemRenderer) {
    var that = seatItem;
    var mapRenderer = seatMapRenderer;
    var itemRenderer = itemRenderer;
    var CLICK_POSITION_THRESHOLD = 30;

    that.activate = function() {
        if (!that.selectIndicatorUI) {
            var indicator = that.indicator;
            that.selectIndicatorUI = itemRenderer.paper.image(mapRenderer.baseAssetPath + indicator.assetPath, indicator.x, indicator.y, indicator.width, indicator.height);
            that.selectIndicatorUI.transform(indicator.tranString);

            if (that.passengerIndicatorUI) {
                that.passengerIndicatorUI.remove();
            }
            that.passengerIndicatorUI = itemRenderer.paper.text(indicator.fontX, indicator.fontY, that.passengerLabel).attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#FFF"});
            that.passengerIndicatorUI.transform(indicator.tranString);
            //that.selectIndicatorUI = itemRenderer.paper.rect(indicator.x, indicator.y, indicator.width, indicator.height, indicator.height / 8).attr({"stroke-width":0, stroke:"#FF664e", fill: "#FF664e"});
            //that.selectIndicatorUI.transform(indicator.tranString);
            //that.selectIndicatorUI = that.clickUI.glow({color:"#FFd700", opacity:1, fill:false});
            //that.selectIndicatorUI.transform(indicator.tranString);
            mapRenderer.indicatorRenderer.resetIndicatorZOrder();
        }
    };

    that.deactivate = function() {
        if (that.selectIndicatorUI) {
            that.selectIndicatorUI.remove();
            that.selectIndicatorUI = null;
        }
    };

    that.deselect = function() {
        if (that.passengerIndicatorUI) {
            that.selected = false;
            itemRenderer.drawSeatUI(that);
            that.clickUI.touchstart(function () {
                that.touchStartTime = new Date().getTime();
            });

            that.clickUI.touchend(function() {
                if (!that.touchStartTime) that.touchStartTime = 0;
                var interval = new Date().getTime() - that.touchStartTime;
                if (interval < 400) {
                    mapRenderer.seatSelector.setSelectedSeatNo(that);
                }
            });
            that.passengerIndicatorUI.remove();
            that.passengerIndicatorUI = null;
            mapRenderer.indicatorRenderer.resetIndicatorZOrder();
        }
    };

    that.selectFor = function(passengerLabel) {
        that.passengerLabel = passengerLabel;
        if (!that.passengerIndicatorUI) {
            that.selected = true;
            itemRenderer.drawSeatUI(that);
            that.clickUI.touchstart(function (e) {
                if (e.touches.length == 1) {
                    that.touchStartX = e.touches[0].clientX;
                    that.touchStartY = e.touches[0].clientY;
                } else {
                    that.touchStartX = -1;
                    that.touchStartY = -1;
                }
            });

            that.clickUI.touchend(function(e) {
                if (e.changedTouches.length == 1) {
                    var diffX = Math.abs(e.changedTouches[0].clientX - that.touchStartX);
                    var diffY = Math.abs(e.changedTouches[0].clientY - that.touchStartY);
                    if (diffX + diffY < CLICK_POSITION_THRESHOLD) {
                        mapRenderer.seatSelector.setSelectedSeatNo(that);
                    }
                }
            });
            var indicator = that.indicator;
            that.passengerIndicatorUI = itemRenderer.paper.text(indicator.fontX, indicator.fontY, passengerLabel).attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#FFF"});
            that.passengerIndicatorUI.transform(indicator.tranString);
            mapRenderer.indicatorRenderer.resetIndicatorZOrder();
        }
    };

    if (that.clickUI) {
        that.clickUI.touchstart(function (e) {
            if (e.touches.length == 1) {
                that.touchStartX = e.touches[0].clientX;
                that.touchStartY = e.touches[0].clientY;
            } else {
                that.touchStartX = -1;
                that.touchStartY = -1;
            }
        });

        that.clickUI.touchend(function(e) {
            if (e.changedTouches.length == 1) {
                var diffX = Math.abs(e.changedTouches[0].clientX - that.touchStartX);
                var diffY = Math.abs(e.changedTouches[0].clientY - that.touchStartY);
                if (diffX + diffY < CLICK_POSITION_THRESHOLD) {
                    mapRenderer.seatSelector.setSelectedSeatNo(that);
                }
            }
        });
    }

    return that;
}

var cBaseSeatRenderer = function(paper, mapRenderer) {
    var SEAT_ASSET_PREFIX_MAPPING = {
        F: "sm_first",
        J: "sm_old_business",
        NJ: "sm_business",
        Y: "sm_economy",
        W: "sm_economy"
    };
    var that = cBaseRenderer(paper, mapRenderer);
    that.SEAT_AVAILABLE = "F";
    that.ADDON_EXTRA_LEG = "X";
    that.ADDON_BASSINET = "B";
    that.ROW_EXIT = "X";
    
    
    that.seatPath = cSeatPath();

    that.getAssetImage = function(seatMapItem) {
        var suffix = ".svg";
        var seatType = seatMapItem.seatType;
        var parts = [that.baseAssetPath];

        parts.push(SEAT_ASSET_PREFIX_MAPPING[seatType]);
        if (seatMapItem.addon && seatMapItem.addon == that.ADDON_EXTRA_LEG) {
            parts.push("_extra_leg");
        }

        if (seatMapItem.rowFlag && seatMapItem.rowFlag.indexOf(that.ROW_EXIT) >= 0) {
            parts.push("_exit_row");
        }

        if (seatMapItem.selected) {
            parts.push("_selected");
        } else if (seatMapItem.status == that.SEAT_AVAILABLE) {
            parts.push("_available");
        } else {
            parts.push("_unavailable");
        }

        if (seatMapItem.classifier) {
            parts.push(seatMapItem.classifier);
        }

        parts.push(suffix);
        return parts.join("");
    };

    that.drawSeatOutline = function(pathInfo, x, y, width, height, tranString) {
        var ratio = width / pathInfo.width;
        var outlineOffsetX = (pathInfo.width - width) / 2;
        var outlineOffsetY = (pathInfo.height - height) / 2;
        var outlineTranString = "S" + ratio +"T" + (x - outlineOffsetX) + "," + (y - outlineOffsetY);
        return that.paper.path(pathInfo.path).transform(outlineTranString + tranString).attr({'fill': '#FFFFFF','fill-opacity': '0.0','stroke-width': '0','stroke-opacity': '0'});
    };

    that.render = function(seatMapItem) {
        seatMapItem.indicator = that.createIndicatorRenderParam(seatMapItem);
        that.drawSeatUI(seatMapItem);
        return cSeatSelectionControl(seatMapItem, that.mapRenderer, that);
    };

    return that;
};

var cFirstClassSeatRenderer = function(paper, mapRenderer) {
    var that = cBaseSeatRenderer(paper, mapRenderer);
    var FIRST_RATIO = 0.51961;
    var FIRST_CENTRE_RATIO = 0.38813;
    var BASSINET_RATIO = 1.1884;
    var SEAT_WIDTH_HEIGHT_RATIO = 1.26;
    var SEAT_WIDTH_TO_WHOLE_SEAT_RATIO = 0.5806;
    var SEAT_WIDTH_TO_CENTER_WHOLE_SEAT_RATIO = 0.7657;
    var SEAT_ACTIVE_EXPAND_RATIO = 1.1;
    var SEAT_CENTER_X_RATIO = 0.6643;
    var CENTER_SEAT_CENTER_X_RATIO = 0.5452;
    var SEAT_CENTER_Y_RATIO = 0.7838;

    var calculateRotationTranString = function(seatMapItem) {
        // First class seat offset and rotation
        var offsetX = seatMapItem.width * 0.46 - seatMapItem.y * 0.001;
        if (seatMapItem.seatNo >= "D"  && seatMapItem.seatNo <= "G") {
            if (seatMapItem.rotationAngle == 0) {
                offsetX = 0;
            } else {
                offsetX =  -seatMapItem.width * 0.54 + seatMapItem.y * 0.001;
            }
        }
        var offsetY = seatMapItem.height * ( 1 - Math.cos(seatMapItem.rotationAngle * Math.PI / 180)) +  (seatMapItem.y * seatMapItem.y) * 0.00005;
        var transString;
        if (seatMapItem.isLeft) {
            transString = "R" +seatMapItem.rotationAngle + "," + seatMapItem.rotationX + "," + seatMapItem.rotationY + "S-1,1T-" + offsetX + "," + offsetY;
        } else {
            transString = "R" +seatMapItem.rotationAngle + "," + seatMapItem.rotationX + "," + seatMapItem.rotationY + "T" + offsetX + "," + offsetY;
        }
        if (seatMapItem.flip) {
            transString = transString + "S-1,1";
        }
        return transString;
    }

    var calculateIndicatorTranString = function(seatMapItem) {
        // First class seat offset and rotation
        var offsetX = seatMapItem.width * 0.46 - seatMapItem.y * 0.001;
        if (seatMapItem.seatNo >= "D"  && seatMapItem.seatNo <= "G") {
            if (seatMapItem.rotationAngle == 0) {
                if (!seatMapItem.flip) {
                    offsetX = 0;
                } else {
                    offsetX = - seatMapItem.width * 0.1;
                }
            } else {
                offsetX = - seatMapItem.width * 0.54 + seatMapItem.y * 0.001;
            }
        }
        var offsetY = seatMapItem.height * ( 1 - Math.cos(seatMapItem.rotationAngle * Math.PI / 180)) +  (seatMapItem.y * seatMapItem.y) * 0.00005;
        var transString;
        if (seatMapItem.isLeft) {
            transString = "R" +seatMapItem.rotationAngle + "," + seatMapItem.rotationX + "," + seatMapItem.rotationY + "T-" + offsetX + "," + offsetY;
        } else {
            transString = "R" +seatMapItem.rotationAngle + "," + seatMapItem.rotationX + "," + seatMapItem.rotationY + "T" + offsetX + "," + offsetY;
        }
        //if (seatMapItem.flip) {
        //    transString = transString + "S-1,1";
        //}
        return transString;
    }

    that.createIndicatorRenderParam = function(seatMapItem) {
        var indicator = {
            assetPath: "sm_business_active.svg",
            width: 0,
            height: 0,
            tranString: "",
            fontSize: seatMapItem.height / 7
        };
        if (seatMapItem.classifier == "_centre") {
            indicator.width = seatMapItem.width * SEAT_WIDTH_TO_CENTER_WHOLE_SEAT_RATIO * SEAT_ACTIVE_EXPAND_RATIO;
            indicator.height = indicator.width / SEAT_WIDTH_HEIGHT_RATIO;
            indicator.x = seatMapItem.x + seatMapItem.width * CENTER_SEAT_CENTER_X_RATIO - indicator.width / 2;
            indicator.y = seatMapItem.y + seatMapItem.height * SEAT_CENTER_Y_RATIO - indicator.height / 2;
            indicator.fontX = seatMapItem.x + seatMapItem.width * 0.55;
            indicator.fontY = seatMapItem.y + seatMapItem.height * 0.75;
            indicator.bassinetX = seatMapItem.x + seatMapItem.width * 0.18;
            indicator.bassinetY = seatMapItem.y + seatMapItem.height * 0.20;
        } else if (seatMapItem.isLeft) {
            indicator.width = seatMapItem.width * SEAT_WIDTH_TO_WHOLE_SEAT_RATIO * SEAT_ACTIVE_EXPAND_RATIO;
            indicator.height = indicator.width / SEAT_WIDTH_HEIGHT_RATIO;
            indicator.x = seatMapItem.x + seatMapItem.width * SEAT_CENTER_X_RATIO - indicator.width / 2;
            indicator.y = seatMapItem.y + seatMapItem.height * SEAT_CENTER_Y_RATIO - indicator.height / 2;
            indicator.fontX = seatMapItem.x + seatMapItem.width * 0.66;
            indicator.fontY = seatMapItem.y + seatMapItem.height * 0.75;
            indicator.bassinetX = seatMapItem.x + seatMapItem.width * 0.38;
            indicator.bassinetY = seatMapItem.y + seatMapItem.height * 0.20;
        } else {
            indicator.width = seatMapItem.width * SEAT_WIDTH_TO_WHOLE_SEAT_RATIO * SEAT_ACTIVE_EXPAND_RATIO;
            indicator.height = indicator.width / SEAT_WIDTH_HEIGHT_RATIO;
            indicator.x = seatMapItem.x + seatMapItem.width * (1 - SEAT_CENTER_X_RATIO) - indicator.width / 2;
            indicator.y = seatMapItem.y + seatMapItem.height * SEAT_CENTER_Y_RATIO - indicator.height / 2;
            indicator.fontX = seatMapItem.x + seatMapItem.width * 0.34;
            indicator.fontY = seatMapItem.y + seatMapItem.height * 0.75;
            indicator.bassinetX = seatMapItem.x + seatMapItem.width * 0.28;
            indicator.bassinetY = seatMapItem.y + seatMapItem.height * 0.20;
        }

        var transString = calculateIndicatorTranString(seatMapItem);
        indicator.tranString = transString;
        return indicator;
    };

    that.drawSeatUI = function(seatMapItem) {
        if (seatMapItem.seatUI) seatMapItem.seatUI.remove();
        if (seatMapItem.clickUI) seatMapItem.clickUI.remove();
        var assetImage = that.getAssetImage(seatMapItem);
        var transString = calculateRotationTranString(seatMapItem);
        // Draw UI
        seatMapItem.seatUI = that.paper.set();
        seatMapItem.seatUI.push(that.paper.image(assetImage, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height).transform(transString));
        var indicator = seatMapItem.indicator;
        // drawing the priority tag
        if(seatMapItem.isPriority && !seatMapItem.selected && seatMapItem.status == that.SEAT_AVAILABLE) {
            var priorityUI = that.paper.text(indicator.fontX, indicator.fontY, "P").attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#316C68"});
            priorityUI.transform(indicator.tranString);
            seatMapItem.seatUI.push(priorityUI);
        }
        if(seatMapItem.addon && (seatMapItem.addon == that.ADDON_BASSINET)) {
            var bassinetHeight = seatMapItem.height * 0.15;
            var bassinetWidth = bassinetHeight * BASSINET_RATIO;
            var bassinetUI = that.paper.image(that.baseAssetPath + "sm_bassinet_addon.svg", indicator.bassinetX, indicator.bassinetY, bassinetWidth, bassinetHeight);
            bassinetUI.transform(indicator.tranString);
            seatMapItem.seatUI.push(bassinetUI);
        }
		        
		//drawing the wall
        if(seatMapItem.seatNo >= "D" && seatMapItem.seatNo <= "G" && !seatMapItem.flip) {
        	console.log("drawing the wall for seats in center");
        	var radius = Math.floor(seatMapItem.width / 30);
        	var wallWidth = seatMapItem.width / 20;
        	var wallHeight = seatMapItem.height * Math.cos(seatMapItem.rotationAngle * Math.PI / 180);
        	var wallX = seatMapItem.x - seatMapItem.width * 0.27;
        	var wallY = seatMapItem.y + (seatMapItem.height - wallHeight) * 0.85 + (seatMapItem.y * seatMapItem.y) * 0.00005;
        	seatMapItem.seatUI.push(that.paper.rect(wallX, wallY, wallWidth, wallHeight).attr({fill: "#C9C9C9", "stroke-width" :0, r: radius}));
        }
        
        seatMapItem.seatUI.insertAfter(that.mapRenderer.bgUI);
        if(seatMapItem.status == that.SEAT_AVAILABLE) {
            if (seatMapItem.classifier == "_centre") {
                seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.FIRST_CLASS_MIDDLE_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, transString);
            } else {
                seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.FIRST_CLASS_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, transString);
            }
        }

        
    };

    that.computeHeight = function(width, seatType, item) {
        var span = item.span? item.span: 1;
        var widthRatio = mapRenderer.config.seatWidthRatio? mapRenderer.config.seatWidthRatio: 1;
        var itemWidth = width * span * widthRatio;
        return Math.floor(itemWidth / FIRST_RATIO);
    };

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.height = seatMapItem.boundHeight;
        // Add modifier for center seat with no rotation
        if (seatMapItem.seatNo >= "D" && seatMapItem.seatNo <= "G" && !seatMapItem.rotationAngle) {
            console.log("First Class seat " + seatMapItem.seatNo + ":" + seatMapItem.rotationAngle + ": Use Center");
            seatMapItem.classifier = "_centre";
            seatMapItem.width = Math.floor(seatMapItem.height * FIRST_CENTRE_RATIO);
        } else {
            seatMapItem.classifier = "_right";
            seatMapItem.width = Math.floor(seatMapItem.height * FIRST_RATIO);
        }
        console.log(seatMapItem.classifier);
    };

    return that;
}

var cEconomyClassAndRegionalSeatRenderer = function(paper, mapRenderer) {
    var that = cBaseSeatRenderer(paper, mapRenderer);
    var ECON_RATIO = 1.1818;
    var ECON_ADDON_RATIO = 0.61;
    var BASSINET_RATIO = 1.1884;
    var SELECTED_SEAT_EXPAND_RATIO = 1.11;
    var SELECTED_SEAT_WIDTH_HEIGHT_RATIO = 1.0488;
    var SEAT_ACTIVE_CENTER_Y_OFFSET = 0.4512;

    that.createIndicatorRenderParam = function(seatMapItem) {
        var indicatorWidth = seatMapItem.width * SELECTED_SEAT_EXPAND_RATIO;
        var indicatorHeight = indicatorWidth / SELECTED_SEAT_WIDTH_HEIGHT_RATIO;
        var seatHeight = seatMapItem.width / ECON_RATIO;
        var indicator = {
            assetPath: "sm_economy_active.svg",
            width: indicatorWidth,
            height: indicatorHeight,
            x: seatMapItem.x + (seatMapItem.width - indicatorWidth) / 2,
            y: seatMapItem.y + seatMapItem.height - (seatHeight / 2) - indicatorHeight * SEAT_ACTIVE_CENTER_Y_OFFSET,
            tranString: "",
            fontSize: seatMapItem.width * 0.35,
            fontX: seatMapItem.x + seatMapItem.width / 2,
            fontY: seatMapItem.y + seatMapItem.height / 2.6
        };
        if (seatMapItem.addon && seatMapItem.addon != that.ADDON_BASSINET) {
            indicator.fontY =   seatMapItem.y + seatMapItem.height * 0.68;
        }
        return indicator;
    };

    that.drawSeatUI = function(seatMapItem) {
        if (seatMapItem.seatUI) seatMapItem.seatUI.remove();
        var assetImage = that.getAssetImage(seatMapItem);

        // Bassinet UI
        var bassinet = null;
        if(seatMapItem.addon && (seatMapItem.addon == that.ADDON_BASSINET)) {
			//console.log("start to draw baby bassinet, the item's seatNo is " + seatMapItem.seatNo);
            var bassinetHeight =  (seatMapItem.width / ECON_ADDON_RATIO - seatMapItem.height) * 0.8;
            //(seatMapItem.y - seatMapItem.boundY) * 0.8;
            var bassinetWidth = bassinetHeight * BASSINET_RATIO;
            var bassinetX = seatMapItem.boundX + (seatMapItem.boundWidth - bassinetWidth) / 2;
            var bassinetY = seatMapItem.y - bassinetHeight-(seatMapItem.height) / 10;
			console.log("start to draw baby bassinet, the item's x and y are " + bassinetX + ", " + bassinetY);
            //seatMapItem.boundY + (seatMapItem.y - seatMapItem.boundY - bassinetHeight) / 2;
            bassinet = that.paper.image(that.baseAssetPath + "sm_bassinet_addon.svg", bassinetX, bassinetY, bassinetWidth, bassinetHeight);
        }
        // Draw UI
        seatMapItem.seatUI = that.paper.set();
        var seatUI = that.paper.image(assetImage, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height);
        seatMapItem.seatUI.push(seatUI);
        if (bassinet) seatMapItem.seatUI.push(bassinet);

        // drawing the priority tag
        if(seatMapItem.isPriority && !seatMapItem.selected && seatMapItem.status == that.SEAT_AVAILABLE) {
            var indicator = seatMapItem.indicator;
            var priorityUI = that.paper.text(indicator.fontX, indicator.fontY, "P").attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#316C68"});
            priorityUI.transform(indicator.tranString);
            seatMapItem.seatUI.push(priorityUI);
        }
        seatMapItem.clickUI = seatMapItem.seatUI;
    };

    that.computeHeight = function(width, seatType, item, blockIndex, rowIndex) {
        var span = item.span? item.span: 1;
        var widthRatio = mapRenderer.config.seatWidthRatio? mapRenderer.config.seatWidthRatio: 1;
        var itemWidth = width * span * widthRatio;
		if (item.addon && (item.addon == that.ADDON_EXTRA_LEG || item.addon == that.ADDON_BASSINET) && 
			blockIndex === 0 && rowIndex === 0) {
            return Math.floor(itemWidth / ECON_ADDON_RATIO);
        } else {
            return Math.floor(itemWidth / ECON_RATIO);
        }
    };

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = seatMapItem.boundWidth * 0.9;
        seatMapItem.height = Math.floor(seatMapItem.width / ECON_RATIO);
        // Extraleg
        if(seatMapItem.addon && (seatMapItem.addon == that.ADDON_EXTRA_LEG)) {
            seatMapItem.height = Math.floor(seatMapItem.width / ECON_ADDON_RATIO);
        }
    };

    return that;
}

var cBusinessClassSeatRenderer = function(paper, mapRenderer) {
    var that = cBaseSeatRenderer(paper, mapRenderer);
    var BUSINESS_RATIO = 0.8584; // Get full height
    var BUSINESS_CONTINUOUS_RATIO = 2.1328; // Get height for sticking seats of previous row
    var BUSINESS_ICON_WIDTH_RATIO = 2.6511;
    var BASSINET_RATIO = 1.1884;
    var SEAT_RATIO = 1;
    var SEAT_TO_AVAILABLE_SPACE_RATIO = 0.9;
    var SELECTED_ICON_RATIO = 1.2;
    var HALF_WALL_LINE_WIDTH_RATIO = 0.0191;

    that.createIndicatorRenderParam = function(seatMapItem) {
        var iconWidth = seatMapItem.width / BUSINESS_ICON_WIDTH_RATIO;
        var iconHeight = iconWidth / SEAT_RATIO;
        var fontSize = seatMapItem.height / 2.6 / BUSINESS_ICON_WIDTH_RATIO;
        var indicatorWidth = iconWidth * SELECTED_ICON_RATIO;
        var indicatorHeight = indicatorWidth / SEAT_RATIO;
        var degree = 44;
        var fontOffsetLeftX = fontSize / 6;
        var fontOffsetLeftY = fontSize / 6;
        var fontOffsetRightX = fontSize / 6;
        var fontOffsetRightY = fontSize / 6;
        var indicatorX, indicatorY, tranString, fontX, fontY;

        // change x of business seat item as the size is smaller than boundWidth, Realign to side
        if (seatMapItem.isLeft) {
        	 seatMapItem.x = seatMapItem.x - seatMapItem.boundWidth / 20 - seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
        } else {
        	seatMapItem.x = seatMapItem.x + seatMapItem.boundWidth / 20 + seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
        }

        var seatRotatedHeight = iconWidth * Math.sin(degree * Math.PI / 180) + iconHeight * Math.cos((90 - degree) * Math.PI / 180);
        var seatRotatedWidth = iconWidth * Math.cos(degree * Math.PI / 180) + iconHeight * Math.cos((90 - degree) * Math.PI / 180);
        if(seatMapItem.isLeft) {
            indicatorX = seatMapItem.x + (seatRotatedWidth - iconWidth * SELECTED_ICON_RATIO) / 2 + seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
            indicatorY = seatMapItem.y + seatMapItem.height - seatRotatedHeight  + (seatRotatedHeight - iconHeight * SELECTED_ICON_RATIO) / 2;
            tranString = "r" + degree;
            fontX = indicatorX + iconWidth * SELECTED_ICON_RATIO / 2 + fontOffsetLeftX;
            fontY = seatMapItem.y + seatMapItem.height - seatRotatedHeight / 2 - fontOffsetLeftY;
        } else {
            indicatorX = seatMapItem.x + seatMapItem.width - seatRotatedWidth + (seatRotatedWidth - iconWidth * SELECTED_ICON_RATIO) / 2 - seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
            indicatorY = seatMapItem.y + seatMapItem.height - seatRotatedHeight  + (seatRotatedHeight - iconHeight * SELECTED_ICON_RATIO) / 2;
            fontX = indicatorX + iconWidth * SELECTED_ICON_RATIO / 2 - fontOffsetRightX;
            fontY = seatMapItem.y + seatMapItem.height - seatRotatedHeight / 2 - fontOffsetRightY;
            tranString = "r-" + degree;
        }

        var indicator = {
            assetPath: "sm_business_active.svg",
            width: indicatorWidth,
            height: indicatorHeight,
            x: indicatorX,
            y: indicatorY,
            tranString: tranString,
            fontSize: fontSize,
            fontX: fontX,
            fontY: fontY
        };
        return indicator;
    };

    that.drawSeatUI = function(seatMapItem) {
        if (seatMapItem.seatUI) seatMapItem.seatUI.remove();
        if (seatMapItem.clickUI) seatMapItem.clickUI.remove();
        var assetImage = that.getAssetImage(seatMapItem);
       
        // Bassinet UI
        var bassinet = null;
        if(seatMapItem.addon && (seatMapItem.addon == that.ADDON_BASSINET)) {
            var bassinetHeight = seatMapItem.height * 0.28;
            var bassinetWidth = bassinetHeight * BASSINET_RATIO;
            var bassinetX;
            if (!seatMapItem.isLeft) {
                bassinetX = seatMapItem.x + (seatMapItem.width * 0.95 - bassinetWidth);
            } else {
                bassinetX = seatMapItem.x + (seatMapItem.width * 0.05);
            }
            var bassinetY = seatMapItem.y;
            bassinet = that.paper.image(that.baseAssetPath + "sm_bassinet_addon.svg", bassinetX, bassinetY, bassinetWidth, bassinetHeight);
        }
        
       
        // Draw UI
        seatMapItem.seatUI = that.paper.set();
        var seatUI = that.paper.image(assetImage, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height);
        seatMapItem.seatUI.push(seatUI);
        if (bassinet) seatMapItem.seatUI.push(bassinet);

        // drawing the priority tag
        if(seatMapItem.isPriority && !seatMapItem.selected && seatMapItem.status == that.SEAT_AVAILABLE) {
            var indicator = seatMapItem.indicator;
            var priorityUI = that.paper.text(indicator.fontX, indicator.fontY, "P").attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#316C68"});
            priorityUI.transform(indicator.tranString);
            seatMapItem.seatUI.push(priorityUI);
        }
		seatMapItem.seatUI.insertAfter(that.mapRenderer.bgUI);
		if(seatMapItem.status == that.SEAT_AVAILABLE) {
			if (seatMapItem.isLeft) {
	            seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.OLD_BUSINESS_LEFT_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, "");
	        } else {
	            seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.OLD_BUSINESS_RIGHT_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, "");
	        }
		}
        
	    
    };

    that.computeHeight = function(width, seatType, item) {
        var span = item.span? item.span: 1;
        var widthRatio = mapRenderer.config.seatWidthRatio? mapRenderer.config.seatWidthRatio: 1;
        var itemWidth = width * span * widthRatio;
        if(item.isComplete) {
            return Math.floor(itemWidth / BUSINESS_RATIO);
        } else {
            return Math.floor(itemWidth / BUSINESS_CONTINUOUS_RATIO);
        }
    };

    that.calculateItemSize = function(seatMapItem) {
        if (seatMapItem.isLeft) {
            seatMapItem.classifier = "_left";
        } else {
            seatMapItem.classifier = "_right";
        }
        seatMapItem.width = seatMapItem.boundWidth * SEAT_TO_AVAILABLE_SPACE_RATIO;
        seatMapItem.height = Math.floor(seatMapItem.width / BUSINESS_RATIO);
    };

    return that;
}

var cNewBusinessClassSeatRenderer = function(paper, mapRenderer) {
    var that = cBaseSeatRenderer(paper, mapRenderer);
    var BUSINESS_RATIO = 0.81017;
    var BUSINESS_ICON_RATIO = 1.45;
    var BUSINESS_ICON_WIDTH_RATIO = 2.4706;
    var BASSINET_RATIO = 1.1884;
    var SEAT_RATIO = 1.133;
    var SEAT_TO_AVAILABLE_SPACE_RATIO = 0.9;
    var SEAT_CENTER_X_RATIO = 0.6833;
    var SEAT_CENTER_Y_RATIO = 0.7549;
    var HALF_WALL_LINE_WIDTH_RATIO = 0.0191;
    var SELECTED_ICON_RATIO = 1.18;

    that.createIndicatorRenderParam = function(seatMapItem) {
        var iconWidth = seatMapItem.width / BUSINESS_ICON_WIDTH_RATIO;
        var iconHeight = iconWidth / SELECTED_ICON_RATIO;
        var fontSize = seatMapItem.height / 2.6 / BUSINESS_ICON_WIDTH_RATIO;
        var indicatorWidth = iconWidth * SELECTED_ICON_RATIO;
        var indicatorHeight = indicatorWidth / SEAT_RATIO;
        var degree = 30;
        var fontOffsetLeftX = fontSize / 7;
        var fontOffsetLeftY = fontSize / 4;
        var fontOffsetRightX = fontSize / 7;
        var fontOffsetRightY = fontSize / 4;
        var indicatorX, indicatorY, tranString, fontX, fontY;
        
        //change the x of new business seat item, align to the wall
		if (seatMapItem.isLeft) {
        	seatMapItem.x = seatMapItem.x - seatMapItem.boundWidth / 20 - seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
        } else {
        	seatMapItem.x = seatMapItem.x + seatMapItem.boundWidth / 20 + seatMapItem.width * HALF_WALL_LINE_WIDTH_RATIO;
        }


        var seatRotatedHeight = iconWidth * Math.sin(degree * Math.PI / 180) + iconHeight * Math.cos((90 - degree) * Math.PI / 180);
        var seatRotatedWidth = iconWidth * Math.cos(degree * Math.PI / 180) + iconHeight * Math.cos((90 - degree) * Math.PI / 180);
        if(!seatMapItem.isLeft) {
            indicatorX = seatMapItem.x + seatMapItem.width * (1 - SEAT_CENTER_X_RATIO) - indicatorWidth / 2;
            indicatorY = seatMapItem.y + seatMapItem.height * SEAT_CENTER_Y_RATIO - indicatorHeight / 2;
            tranString = "r" + degree;
            fontX = indicatorX + iconWidth * SELECTED_ICON_RATIO / 2 + fontOffsetLeftX;
            fontY = indicatorY + iconHeight * SELECTED_ICON_RATIO / 2 - fontOffsetLeftY;
        } else {
            indicatorX = seatMapItem.x + seatMapItem.width * SEAT_CENTER_X_RATIO - indicatorWidth / 2;
            indicatorY = seatMapItem.y + seatMapItem.height * SEAT_CENTER_Y_RATIO - indicatorHeight / 2;
            fontX = indicatorX + iconWidth * SELECTED_ICON_RATIO / 2 - fontOffsetRightX;
            fontY = indicatorY + iconHeight * SELECTED_ICON_RATIO / 2 - fontOffsetRightY;
            tranString = "r-" + degree;
        }


        //if(!seatMapItem.isLeft) {
        //    indicatorX = seatMapItem.x + 3 * offsetX;
        //    indicatorY = seatMapItem.y + seatMapItem.height - iconWidth * Math.sin(degree * Math.PI / 180) / 2 - offsetY;
        //    tranString = "r" + degree;
        //    fontX = indicatorX + iconWidth * (Math.cos(degree * Math.PI / 180) + Math.sin(degree * Math.PI / 180)) / 2 + fontOffsetLeftX;
        //    fontY = indicatorY - iconWidth * Math.sin(degree * Math.PI / 180) / 2 - fontOffsetLeftY;
        //} else {
        //    indicatorX = seatMapItem.x + seatMapItem.width - iconWidth * Math.cos(degree * Math.PI / 180) - offsetX;
        //    indicatorY = seatMapItem.y + seatMapItem.height - iconWidth * Math.sin(degree * Math.PI / 180) / 2 - offsetY;
        //    fontX = indicatorX - iconWidth * (Math.sin(degree * Math.PI / 180) - Math.cos(degree * Math.PI / 180)) / 2 - fontOffsetRightX;
        //    fontY = indicatorY - iconWidth * Math.sin(degree * Math.PI / 180) / 2 - fontOffsetRightY;
        //    tranString = "r-" + degree;
        //}

        var indicator = {
            assetPath: "sm_business_active.svg",
            width: indicatorWidth,
            height: indicatorHeight,
            x: indicatorX,
            y: indicatorY,
            tranString: tranString,
            fontSize: fontSize,
            fontX: fontX,
            fontY: fontY
        };
        return indicator;
    };

    that.drawSeatUI = function(seatMapItem) {
        if (seatMapItem.seatUI) seatMapItem.seatUI.remove();
        if (seatMapItem.clickUI) seatMapItem.clickUI.remove();
        var assetImage = that.getAssetImage(seatMapItem);
        
        // Bassinet UI
        var bassinet = null;
        if(seatMapItem.addon && (seatMapItem.addon == that.ADDON_BASSINET)) {
            var bassinetHeight = seatMapItem.height * 0.30;
            var bassinetWidth = bassinetHeight * BASSINET_RATIO;
            var bassinetX;
            if (seatMapItem.isLeft) {
                bassinetX = seatMapItem.x + (seatMapItem.width - bassinetWidth);
            } else {
                bassinetX = seatMapItem.x;
            }
            var bassinetY = seatMapItem.y;
            bassinet = that.paper.image(that.baseAssetPath + "sm_bassinet_addon.svg", bassinetX, bassinetY, bassinetWidth, bassinetHeight);
        }
        // Draw UI
        seatMapItem.seatUI = that.paper.set();
        var seatUI = that.paper.image(assetImage, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height);
        seatMapItem.seatUI.push(seatUI);
        if (bassinet) seatMapItem.seatUI.push(bassinet);
        

        // drawing the priority tag
        if(seatMapItem.isPriority && !seatMapItem.selected && seatMapItem.status == that.SEAT_AVAILABLE) {
            var indicator = seatMapItem.indicator;
            var priorityUI = that.paper.text(indicator.fontX, indicator.fontY, "P").attr({"font-size": indicator.fontSize, "font-family": "Arial, Helvetica, sans-serif", fill: "#316C68"});
            priorityUI.transform(indicator.tranString);
            seatMapItem.seatUI.push(priorityUI);
        }
		seatMapItem.seatUI.insertAfter(that.mapRenderer.bgUI);
		if(seatMapItem.status == that.SEAT_AVAILABLE) {
			if (seatMapItem.isLeft) {
	            seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.NEW_BUSINESS_LEFT_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, "");
	        } else {
	            seatMapItem.clickUI = that.drawSeatOutline(that.seatPath.NEW_BUSINESS_RIGHT_SEAT, seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height, "");
	        }
		}
       
        //seatMapItem.clickUI = seatMapItem.seatUI;
    };

    that.computeHeight = function(width, seatType, item) {
        var span = item.span? item.span: 1;
        var widthRatio = mapRenderer.config.seatWidthRatio? mapRenderer.config.seatWidthRatio: 1;
        var itemWidth = width * span * widthRatio;
        console.log("Seat width " + itemWidth);
        if(item.isComplete) {
            return Math.floor(itemWidth / BUSINESS_RATIO);
        }else {
            return Math.floor(itemWidth / BUSINESS_ICON_RATIO);
        }
    };

    that.calculateItemSize = function(seatMapItem) {
        if (seatMapItem.isLeft) {
            seatMapItem.classifier = "_left";
        } else {
            seatMapItem.classifier = "_right";
        }
        seatMapItem.width = seatMapItem.boundWidth * SEAT_TO_AVAILABLE_SPACE_RATIO;
        seatMapItem.height = Math.floor(seatMapItem.width / BUSINESS_RATIO);

        console.log("Seat size " + seatMapItem.width + ":" + seatMapItem.height);
    };

    return that;
}

var cEmptyRenderer = function(paper, mapRenderer) {

    var RATIO = 10; // svg width / height
    var that = cBaseRenderer(paper, mapRenderer);

    that.render = function(seatMapItem, itemInfo, seatType) {

    }

	that.computeHeight = function(width, seatType, item) {
        return Math.floor(width / RATIO);
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = 0;
        seatMapItem.height = 0;
    };

    return that;
};

var cGalleyRenderer = function(paper, mapRenderer) {
    var RATIO = 1.1; // svg width / height
	var iconRATIO = 1.5894;
    var that = cBaseRenderer(paper, mapRenderer);

    that.render = function(seatMapItem, itemInfo, seatType) {
        that.bottomAlign(seatMapItem);
        that.centerAlign(seatMapItem);
        var radius = Math.floor(seatMapItem.height / 10);
        seatMapItem.galleyUI = that.paper.rect(seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height).attr({fill: "#FFFFFF", stroke: "#CACCCB", "stroke-width" :1, r: radius});

        //for the galley icon
        var iconHeight = Math.min(seatMapItem.height * 0.8, seatMapItem.width * 0.8 / iconRATIO);
        var iconWidth = Math.min(seatMapItem.width * 0.8, seatMapItem.height * 0.8 * iconRATIO);
        var galleyBBox = seatMapItem.galleyUI.getBBox();
        console.log(galleyBBox.x + ":" + galleyBBox.x2);
        var iconX = galleyBBox.x + (galleyBBox.x2 - galleyBBox.x - iconWidth) / 2;
        var iconY = galleyBBox.y + (galleyBBox.y2 - galleyBBox.y - iconHeight) / 2;
        seatMapItem.galleyIconUI = that.paper.image(that.baseAssetPath + "sm_galley.svg", iconX, iconY, iconWidth, iconHeight);
    };
	
	that.computeHeight = function(width, seatType, item) {
		var height = Math.floor(width / RATIO);
		return height;
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = Math.floor(seatMapItem.boundWidth - 1);
        seatMapItem.height = Math.floor(seatMapItem.boundHeight - 1);
    };

    return that;
};

var cToiletRenderer = function(paper, mapRenderer) {
    var RATIO = 1.1; // svg width / height
	var iconRATIO = 1.22;
    var that = cBaseRenderer(paper, mapRenderer);

    that.render = function(seatMapItem, itemInfo, seatType) {
        that.bottomAlign(seatMapItem);
        that.centerAlign(seatMapItem);
        var radius = Math.floor(seatMapItem.height / 10);
        seatMapItem.toiletUI = that.paper.rect(seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height).attr({fill: "#FFFFFF", stroke: "#CACCCB", "stroke-width" :1, r: radius});
		
		//for the toilet icon
        var iconHeight = Math.min(seatMapItem.height * 0.8, seatMapItem.width * 0.8 / iconRATIO);
        var iconWidth = Math.min(seatMapItem.width * 0.8, seatMapItem.height * 0.8 * iconRATIO);
        var toiletBBox = seatMapItem.toiletUI.getBBox();
        var iconX = toiletBBox.x + (toiletBBox.x2 - toiletBBox.x - iconWidth) / 2;
        var iconY = toiletBBox.y + (toiletBBox.y2 - toiletBBox.y - iconHeight) / 2;
        seatMapItem.toiletIconUI = that.paper.image(that.baseAssetPath + "sm_toilet.svg", iconX, iconY, iconWidth, iconHeight);
    };
	
	that.computeHeight = function(width, seatType, item) {
		var height = Math.floor(width / RATIO);
		return height;
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = Math.floor(seatMapItem.boundWidth - 1);
        seatMapItem.height = Math.floor(seatMapItem.boundHeight - 1);
    };

    return that;
};

var cExitRenderer = function(paper, mapRenderer) {

    var RATIO = 1.06; // svg width / height
    var ICON_RATIO = 38/98;//icon width / height
    var OFFSET_HEIGHT_RATIO = 0.025;
    var that = cBaseRenderer(paper, mapRenderer);
    var itemHeight;

    that.render = function(seatMapItem, itemInfo, seatType) {        
        that.bottomAlign(seatMapItem);
        that.centerAlign(seatMapItem);
        //seatMapItem.exitBg =  that.paper.rect(seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height).attr({fill: "#FFFFFF", stroke: "none"});
        var iconWidth = itemHeight / 2;
        var iconHeight = iconWidth / ICON_RATIO;
        var iconOffsetY = seatMapItem.boundWidth * OFFSET_HEIGHT_RATIO;        
        var iconY = seatMapItem.boundY - iconHeight + iconOffsetY;
        if(that.mapRenderer.seatMapData.cabin.indexOf("J") !== -1){
            iconY = seatMapItem.boundY - 3*iconOffsetY;
        }
        var iconOffsetX = (iconWidth - iconWidth / RATIO)/2;
        console.log(iconWidth  + ":" + itemHeight);
        seatMapItem.leftExitUI = that.paper.image(that.baseAssetPath + "sm_exit_door_left.svg", seatMapItem.x-iconWidth+iconOffsetX, iconY, iconWidth, iconHeight);
        seatMapItem.rightExitUI = that.paper.image(that.baseAssetPath + "sm_exit_door_right.svg", seatMapItem.x + seatMapItem.width-iconOffsetX, iconY, iconWidth, iconHeight);
    }
	
	that.computeHeight = function(width, seatType, item) {
		itemHeight = Math.floor(width / RATIO);
		return 0;
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = Math.floor(seatMapItem.boundWidth);
        seatMapItem.height = Math.round(seatMapItem.width / RATIO / seatMapItem.span);
        if (seatMapItem.height > seatMapItem.boundHeight) {
            seatMapItem.height = Math.round(seatMapItem.boundHeight);
        }
    };

    return that;
};

var cAisleRenderer = function(paper, mapRenderer) {
    var that = cBaseRenderer(paper, mapRenderer);

    that.render = function(seatMapItem, itemInfo, seatType) {
        that.topAlign(seatMapItem);
        that.leftAlign(seatMapItem);
        if (that.mapRenderer.config.renderAisle) {
            seatMapItem.aisleUI = that.paper.rect(seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height + mapRenderer.config.rowSpacing).attr({fill: "#FFFFFF", stroke: "none"});
        }
    }

	that.computeHeight = function(width, seatType, item) {
		return undefined;
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = Math.ceil(seatMapItem.boundWidth);
        seatMapItem.height = Math.ceil(seatMapItem.boundHeight + mapRenderer.config.rowSpacing);
    };

    return that;
};

var cStairRenderer = function(paper, mapRenderer) {
    var RATIO = 1.1; // svg width / height
    var that = cBaseRenderer(paper, mapRenderer);

    that.render = function(seatMapItem, itemInfo, seatType) {
        seatMapItem.width = seatMapItem.boundWidth;
        seatMapItem.height = Math.floor(seatMapItem.width / RATIO / seatMapItem.span);
        that.bottomAlign(seatMapItem);
        that.centerAlign(seatMapItem);
        seatMapItem.stairUI =  that.paper.image(that.baseAssetPath + "sm_stairs.svg", seatMapItem.x, seatMapItem.y, seatMapItem.width, seatMapItem.height);//that.paper.rect(x, y, that.width, that.height).attr({fill: "#CACCCB", stroke: "none"});
    }

	that.computeHeight = function(width, seatType, item) {
		var height = Math.floor(width / RATIO);
		return height;
	};

    that.calculateItemSize = function(seatMapItem) {
        seatMapItem.width = seatMapItem.boundWidth;
        seatMapItem.height = seatMapItem.height = Math.floor(seatMapItem.width / RATIO / seatMapItem.span);
        if (seatMapItem.height > seatMapItem.boundHeight) {
            seatMapItem.height = seatMapItem.boundHeight;
        }
    };

    return that;
}



