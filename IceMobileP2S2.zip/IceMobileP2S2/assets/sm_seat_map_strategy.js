/**
 * Created by andyyeung on 17/6/14.
 */
var SEAT_MAP_CONFIGURATION = {
    F: {
        renderAisle: false,
        rowSpacing: 20,
        sideMargin: 0.03,
        seatWidthRatio: 1.5
    },
    J: {
        renderAisle: true,
        rowSpacing: 10,
        sideMargin: 0.06,
        seatWidthRatio: 1
    },
    UpperJ: {
        renderAisle: true,
        rowSpacing: 10,
        sideMargin: 0.23,
        seatWidthRatio: 1
    },
    C: {
        renderAisle: true,
        rowSpacing: 10,
        sideMargin: 0.06,
        seatWidthRatio: 1
    },
    UpperC: {
        renderAisle: true,
        rowSpacing: 10,
        sideMargin: 0.23,
        seatWidthRatio: 1
    },
    W: {
        renderAisle: true,
        rowSpacing: 20,
        sideMargin: 0.06,
        seatWidthRatio: 1
    },
    Y: {
        renderAisle: false,
        rowSpacing: 20,
        sideMargin: 0.06,
        seatWidthRatio: 1
    }
};

// AircraftSceneRenderer
var cBodyRenderer = function(config, paper, baseAssetPath) {
    var BODY_RATIO = 5.9941;
    var SHIFT_RIGHT = 0.02;
    var BODY_BORDER_RATIO_FULL_WIDTH = 0.03;
    var that = {
        paper: paper,
        baseAssetPath: baseAssetPath,
        config: config
    };

    that.render = function(x, y, width, height) {
        var bodyWidth = Math.ceil(width * (1 - (that.config.sideMargin - BODY_BORDER_RATIO_FULL_WIDTH * (1 - that.config.sideMargin * 2) / (1 - 0.06 * 2)) * 2));
        var bodyHeight = Math.floor(bodyWidth / BODY_RATIO);
        bodyWidth = Math.ceil(bodyHeight * BODY_RATIO);
        var offsetX = Math.round((width - bodyWidth) * 0.5 + (width * SHIFT_RIGHT));
        var repeat = Math.ceil(height / bodyHeight);
        var bodyUI = that.paper.set();
        for (var i = 0; i < repeat; i++) {
            bodyUI.push(that.paper.image(that.baseAssetPath + "sm_aircraft_mid.svg", x + offsetX, i * bodyHeight + Math.round(y), bodyWidth, bodyHeight + 1));
        }
        return bodyUI;
    };

    return that;
};

var cNoseRenderer = function(config, paper, baseAssetPath) {
    var that = {
        paper: paper,
        baseAssetPath: baseAssetPath,
        config: config
    };

    that.render = function(x, y, width, height) {
        var bodyUI = that.paper.set();
        var height = Math.round(height / 2);
        bodyUI.push(that.paper.image(that.baseAssetPath + "sm_aircraft_nose_a_1.svg", x, y, width, height));
        bodyUI.push(that.paper.image(that.baseAssetPath + "sm_aircraft_nose_a_2.svg", x, Math.floor(y + height), width, height));
        return bodyUI;
    };

    return that;
};

var cColumnIndicator = function(y) {
    var that = {
        indicatorNumbers:[],
        indicatorMapping:{},
        y: y
    };

    that.getIndicatorNumbers = function() {
        return that.indicatorNumbers;
    };

    that.addNumber = function(label, x) {
        var indicatorInfo = {
            label: label,
            x: x
        };
        that.indicatorNumbers.push(indicatorInfo);
        that.indicatorMapping[label] = indicatorInfo;
    };

    that.addNumberAt = function(label, x, pos) {
        var indicatorInfo = {
            label: label,
            x: x
        };
        that.indicatorNumbers.splice(pos, 0, indicatorInfo);
        that.indicatorMapping[label] = indicatorInfo;
    };

    that.merge = function(columnIndicator) {
        var mergeable = true;
        var sourceNumbers = columnIndicator.getIndicatorNumbers();
        var insertPool = [];
        for (var i = 0; i < sourceNumbers.length; i++) {
            if (that.indicatorMapping[sourceNumbers[i].label]) {
                var sameNumber = that.indicatorMapping[sourceNumbers[i].label];
                if (sameNumber.x != sourceNumbers[i].x) {
                    return false;
                }
            } else {
                insertPool.push(sourceNumbers[i]);
            }
        }
        if (mergeable) {
            for (var j = 0; j < insertPool.length; j++) {
                var found = false;
                for (var i = 0; i < that.indicatorNumbers.length; i++) {
                    if (that.indicatorNumbers[i].label > insertPool[j].label) {
                        that.addNumberAt(insertPool[j].label, insertPool[j].x, i);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    that.addNumberAt(insertPool[j].label, insertPool[j].x, that.indicatorNumbers.length);
                }
            }
            return true;
        }
    };

    return that;
};

// Row and column indicator renderer
var cBaseIndicatorRenderer = function(config, paper, width, height) {
    var that = {
        config: config,
        paper: paper,
        width: width,
        height: height,
        rowIndicator: null,
        colIndicator: null
    };

    that.drawRowIndicator = function(x1, y1, x2, y2, visibleSeats) {
        var rowIndicatorNumbers = [];
        for (var i = 0; i < visibleSeats.length; i++) {
            rowIndicatorNumbers.push({
                label: visibleSeats[i][0].seatRow,
                //y: visibleSeats[i][0].boundY + visibleSeats[i][0].boundHeight * 0.5
                y: visibleSeats[i][0].indicator.fontY
            });
        }
        var rowIndicatorUI = that.paper.set();
        var padding = (x2 - x1) * 0.01;
        var indicatorWidth = (x2 - x1) * 0.06;
        var scaleRatio = (x2 - x1) / that.paper.width;
        var rectAttr = {fill:"#fff", "fill-opacity":0.6, stroke:"#ddd", "stroke-width": scaleRatio }
        rowIndicatorUI.push(that.paper.rect(x1 + padding, y1 + padding * 4, indicatorWidth, (y2 - y1 - 5 * padding), indicatorWidth / 2).attr(rectAttr));
        for (var i = 0; i < rowIndicatorNumbers.length; i++) {
            var rowIndicatorNumber = rowIndicatorNumbers[i];
            if (rowIndicatorNumber.y > y1 + padding * 4 && rowIndicatorNumber.y < y2 - 4 * padding) {
                var text = that.paper.print(x1 + padding + indicatorWidth/2, rowIndicatorNumber.y, rowIndicatorNumber.label, that.paper.getFont("Aktiv Grotesk"), 14).attr({fill:"#666666"});
                //var text = that.paper.text(x1 + padding + indicatorWidth/2, rowIndicatorNumber.y, rowIndicatorNumber.label).attr({fill:"#666666", "font-size":14, "font-weight":"bold"});
                var textRatio = "t-" + text.getBBox(true).width / 2 + ",0s" + scaleRatio;
                text.transform(textRatio);
                rowIndicatorUI.push(text);
            }
        }
        return rowIndicatorUI;
    };


    that.drawColumnIndicator = function(x1, y1, x2, y2, visibleSeats) {
        var columnIndicatorRows = that.generateColumnIndicatorRows(visibleSeats, x1, y1, x2, y2);
        var padding = (y2 - y1) * 0.01;
        var indicatorHeight = (y2 - y1) * 0.04;
        var colIndicatorUI = that.paper.set();
        var scaleRatio = (y2 - y1) / that.paper.height;
        var rectAttr = {fill:"#fff", "fill-opacity":0.6, stroke:"#ddd", "stroke-width": scaleRatio }
        for (var i = 0; i < columnIndicatorRows.length; i++) {
            var columnIndicator = columnIndicatorRows[i];
            colIndicatorUI.push(that.paper.rect(x1 + padding * 7, columnIndicator.y - indicatorHeight / 2, (x2 - x1 - 9 * padding), indicatorHeight, indicatorHeight / 2).attr(rectAttr));
            for (var j = 0; j < columnIndicator.getIndicatorNumbers().length; j++) {
                var columnNumberInfo = columnIndicator.getIndicatorNumbers()[j];
                if (columnNumberInfo.x > x1 + padding * 7 && columnNumberInfo.x < x2 - padding) {
                    var text = that.paper.print(columnNumberInfo.x, columnIndicator.y, columnNumberInfo.label, that.paper.getFont("Aktiv Grotesk"), 14).attr({fill:"#666666"});
                    //var text = that.paper.text(columnNumberInfo.x, columnIndicator.y, columnNumberInfo.label).attr({fill: "#666666", "font-size": 14, "font-weight":"bold"});
                    var textRatio = "t-" + text.getBBox(true).width / 2 + ",0s" + scaleRatio;
                    text.transform(textRatio);
                    colIndicatorUI.push(text);
                }
            }
        }
        return colIndicatorUI;
    };

    that.showSeatIndicator = function(x1, y1, x2, y2, visibleSeats) {
        if (that.rowIndicator) that.rowIndicator.remove();
        if (that.colIndicator) that.colIndicator.remove();
        that.rowIndicator = that.drawRowIndicator(x1, y1, x2, y2, visibleSeats);
        that.colIndicator = that.drawColumnIndicator(x1, y1, x2, y2, visibleSeats);
    };

    that.hideSeatIndicator = function() {
        if (that.rowIndicator) that.rowIndicator.hide();
        if (that.colIndicator) that.colIndicator.hide();
    };

    that.resetIndicatorZOrder = function() {
        if (that.rowIndicator) that.rowIndicator.toFront();
        if (that.colIndicator) that.colIndicator.toFront();
    };

    return that;
};


var cBlockIndicatorRenderer = function(config, paper, width, height) {
    var that = cBaseIndicatorRenderer(config, paper, width, height);

    that.generateColumnIndicatorRows = function(visibleSeats, x1, y1, x2, y2) {
        var columnIndicatorRows = [];
        var previousColumnIndicator = null;
        var indicatorHeight = (y2 - y1) * 0.04;
        for (var rowIndex = 0; rowIndex < visibleSeats.length; rowIndex++) {
            var y = visibleSeats[rowIndex][0].boundY > y1 + indicatorHeight? visibleSeats[rowIndex][0].boundY - indicatorHeight / 2: y1 + indicatorHeight / 2;
            var columnIndicator = cColumnIndicator(y);
            for (var colIndex = 0; colIndex < visibleSeats[rowIndex].length; colIndex++) {
                columnIndicator.addNumber(visibleSeats[rowIndex][colIndex].seatNo, visibleSeats[rowIndex][colIndex].boundX + visibleSeats[rowIndex][colIndex].boundWidth / 2);
            }
            if (!previousColumnIndicator || !previousColumnIndicator.merge(columnIndicator)) {
                columnIndicatorRows.push(columnIndicator);
            }
            previousColumnIndicator = columnIndicator;
        }
        return columnIndicatorRows;
    };

    return that;
};

var cTopDownIndicatorRenderer = function(config, paper, width, height) {
    var that = cBaseIndicatorRenderer(config, paper, width, height);

    that.generateColumnIndicatorRows = function(visibleSeats, x1, y1, x2, y2) {
        var columnIndicatorRows = [];
        var indicatorHeight = (y2 - y1) * 0.04;
        if (visibleSeats.length > 0) {
            var topY = visibleSeats[0][0].boundY - config.rowSpacing * 0.75 > y1 + indicatorHeight / 2 ? visibleSeats[0][0].boundY - config.rowSpacing * 0.75 : y1 + indicatorHeight / 2;
            var lastY = visibleSeats[visibleSeats.length - 1][0].boundY + visibleSeats[visibleSeats.length - 1][0].height + config.rowSpacing * 0.75;
            var bottomY = lastY < y2 - indicatorHeight / 2 ? lastY : y2 - indicatorHeight / 2;
            var rows = [visibleSeats[0], visibleSeats[visibleSeats.length - 1]];
            var indicatorY = [topY, bottomY];

            for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                var columnIndicator = cColumnIndicator(indicatorY[rowIndex]);
                for (var colIndex = 0; colIndex < rows[rowIndex].length; colIndex++) {
                    columnIndicator.addNumber(rows[rowIndex][colIndex].seatNo, rows[rowIndex][colIndex].boundX + rows[rowIndex][colIndex].boundWidth / 2);
                }
                columnIndicatorRows.push(columnIndicator);
            }
        }
        return columnIndicatorRows;
    };

    return that;
};

// Size Calculator
var cBodySizeCalculator = function(config, itemRenderer) {
    var BODY_RATIO = 5.9941;
    var that = {
        config: config,
        itemRenderer: itemRenderer
    };

    var calculateRowHeight = function(itemMaxWidth, seatType, itemRow, isFacilityPreRow, blockIndex, rowIndex) {
        var itemHeight, rowHeight = 0;
        var seatCount = 0;
        for (var i = 0; i < itemRow.items.length; i++) {
            var item = itemRow.items[i];
            if (!that.itemRenderer[item.type]) {
                console.log("Undefined type: " + item.type);
                continue;
            }
            if(isFacilityPreRow && item.type == "seat") {
            	item.isComplete = true;
            }
            if(item.type == "seat" || item.type == "aisle" || item.type == "empty") {
            	seatCount++;
            }
            if (item.type == "seat") {
                itemHeight = that.itemRenderer[item.type][seatType].computeHeight(itemMaxWidth, seatType, item, blockIndex, rowIndex);
            } else {
                itemHeight = that.itemRenderer[item.type].computeHeight(itemMaxWidth, seatType, item);
            }
            if (itemHeight && itemHeight > rowHeight) {
                rowHeight = itemHeight;
            }
        }
        if(seatCount == itemRow.items.length) {
        	isFacilityPreRow = false;
        }else {
        	isFacilityPreRow = true;
        }
        
        console.log("Row Height for " + i + ":" + rowHeight);
        return {"rowHeight": rowHeight, "isFacilityRow": isFacilityPreRow};
    };

    that.calculate = function(width, seatType, blocks) {
        var totalHeight = 0;
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i];
            var isFacilityRow = true;
            for (var j = 0; j < block.rows.length; j++) {
                var itemMaxWidth = Math.floor(width * (1 - that.config.sideMargin * 2) / block.columnSize);
                var rowMark = calculateRowHeight(itemMaxWidth, seatType, block.rows[j], isFacilityRow, i, j);
                block.rows[j].rowHeight = rowMark.rowHeight;
                totalHeight += (rowMark.rowHeight + that.config.rowSpacing);
                isFacilityRow = rowMark.isFacilityRow;
            }
        }
        var bodyHeight = Math.round(width * (1 - (that.config.sideMargin - 0.03) * 2) / BODY_RATIO);
        var adjustedHeight = Math.ceil(totalHeight / bodyHeight) * bodyHeight;
        return {height: adjustedHeight, width: width, topPadding: 0};
    };

    return that;
};

var cNoseSizeCalculator = function(config, itemRenderer) {
    var that = {
        config: config,
        itemRenderer: itemRenderer
    };
    var NOSE_RATIO = 0.55361;
    var FIRST_CLASS_SEAT_RATIO = 0.51961;
    var SEAT_OVERLAP_RATIO = 0.3702;
    var FACILITY_RATIO = 0.4;
    var FIRST_CLASS_SEAT_OFFSET = 0.23;

    var createLagrange = function(width, height) {
        var lagrange = new Lagrange(0, width / 2, height, 0);
        lagrange.addPoint(height * 0.135, width / 2 * 0.58575);
        lagrange.addPoint(height * 0.25, width / 2 * 0.4059);
        lagrange.addPoint(height * 0.5, width / 2 * 0.1639);
        lagrange.addPoint(height * 0.75, width / 2 * 0.027037);
        lagrange.addPoint(height * 2, 0);
        return lagrange;
    };

    var calculateColSize = function(row) {
        var colSize = 0;
        for (var i = 0; i < row.items.length; i++) {
            var item = row.items[i];
            if (item.type == "empty") continue;
            var span = item.span? item.span: 1;
            var widthRatio = item.widthRatio? item.widthRatio: 1;
            if (item.type == "seat") widthRatio = that.config.seatWidthRatio;
            colSize += span * widthRatio;
        }
        return colSize;
    };

    var calculateRowCount = function(blocks) {
        var count = 0;
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i];
            count += block.rows.length;
        }
        return count;
    };

    var isRowHasSeat = function(row) {
        var seatFound = false;
        for (var i= 0 ;i < row.items.length; i++) {
            if (row.items[i].type == "seat") {
                seatFound = true;
                break;
            }
        }
        return seatFound;
    };

    var isEligibleForCollapsed = function(currentRow, nextRow) {
        // If previous row contains non seat visible item, return false
        var nonSeatFound = false;
        for (var i = 0; i < currentRow.items.length; i++) {
            if (currentRow.items[i].type === "galley" || currentRow.items[i].type === "toilet" || currentRow.items[i].type === "exit") {
                nonSeatFound = true;
                break;
            }
        }
        if (nonSeatFound) return false;
        // If no next row, return false
        if (!nextRow) return false;
        // If next row doesn't contains any seat, return false
        var seatFound = false;
        for (var i = 0; i < nextRow.items.length; i++) {
            if (nextRow.items[i].type === "seat") {
                seatFound = true;
                break;
            }
        }
        if (!seatFound) return false;
        // Return true for other cases
        return true;
    }

    var getRowHeightWithRespectToSeat = function(blocks) {
        var rowHeight = 0;
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i];
            for (var j = 0; j < block.rows.length; j++) {
                var row = block.rows[j];
                if (isRowHasSeat(row)) {
                    row.rowRatio = 1;
                    rowHeight += 1;
                    if (isEligibleForCollapsed(row, block.rows[j+1])) {
                        rowHeight -= SEAT_OVERLAP_RATIO;
                    }
                } else {
                    row.rowRatio = FACILITY_RATIO;
                    rowHeight += FACILITY_RATIO;
                }
            }
        }
        return rowHeight;
    }

    var searchForTopPadding = function(width, height, blocks) {
        var lagrange = createLagrange(width, height);
        var firstRow = blocks[0].rows[0];
        var colSize = calculateColSize(firstRow);
        var rowCount = calculateRowCount(blocks);
        // Find y s.t. (Height-y - totalRowSpacing) * ratio / [rowCount - (rowCount - 1) * overlapRatio] >= (Width - 2 f(y)) / blockColSize
        for (var y = height * 0.135; y < height * 0.6; y += 10) {
            var seatHeightWithOverlap = (height - y - (rowCount-1) * that.config.rowSpacing)  / getRowHeightWithRespectToSeat(blocks);
            var seatWidth = (width - 2 * lagrange.valueOf(y)) / (colSize - FIRST_CLASS_SEAT_OFFSET / that.config.seatWidthRatio * 2) * that.config.seatWidthRatio;
            if (seatHeightWithOverlap * FIRST_CLASS_SEAT_RATIO <= seatWidth) break;
        }
        return y;
    };

    that.calculate = function(width, seatType, blocks) {
        var height = width / NOSE_RATIO;
        var lagrange = createLagrange(width, height);
        var firstRow = blocks[0].rows[0];
        var colSize = calculateColSize(firstRow);
        var topPadding = searchForTopPadding(width, height, blocks);
        var seatHeight = (width - 2 * lagrange.valueOf(topPadding)) / (colSize - FIRST_CLASS_SEAT_OFFSET / that.config.seatWidthRatio * 2) * that.config.seatWidthRatio / FIRST_CLASS_SEAT_RATIO;
        that.config.collapsedRowSpacing = - seatHeight * SEAT_OVERLAP_RATIO; // Special settings to overlap first class seat with previous row
        // Update Row Height
        for (var i = 0; i < blocks.length; i++) {
            var block = blocks[i];
            for (var j = 0; j < block.rows.length; j++) {
                block.rows[j].rowHeight = seatHeight * block.rows[j].rowRatio;
            }
        }
        return {height: height, width: width, topPadding: topPadding};
    };

    return that;
};

// Padding Strategy
var cUniformPositioningStrategy = function(config, offsetX, offsetY, width, height) {
    var SHIFT_RIGHT = 0.02;
    var that = {
        width: width,
        height: height,
        leftBound: width * (config.sideMargin + SHIFT_RIGHT),
        rightBound: width * (1 - config.sideMargin + SHIFT_RIGHT),
        innerWidth: width * (1 - 2 * (config.sideMargin - 0))
    };

    that.getLeftBound = function(y) {
        return that.leftBound;
    };

    that.getRightBound = function(y) {
        return that.rightBound;
    };

    that.getInnerWidth = function(y) {
        return that.innerWidth;
    };

    return that;
};

var cCurvedPositioningStrategy = function(config, offsetX, offsetY, width, height) {
    var that = {
        width: width,
        height: height,
        leftBound: width * config.sideMargin,
        rightBound: width * (1 - config.sideMargin)
    };
    var lagrange = new Lagrange(0, that.width / 2, that.height, 0);
    lagrange.addPoint(that.height * 0.135, that.width / 2 * 0.58575);
    lagrange.addPoint(that.height * 0.25, that.width / 2 * 0.4059);
    lagrange.addPoint(that.height * 0.5, that.width / 2 * 0.1639);
    lagrange.addPoint(that.height * 0.75, that.width / 2 * 0.027037);
    lagrange.addPoint(that.height * 2, 0);

    that.getLeftBound = function(y) {
        return that.leftBound + lagrange.valueOf(y - offsetY);
    };

    that.getRightBound = function(y) {
        return that.rightBound - lagrange.valueOf(y - offsetY);
    };

    that.getInnerWidth = function(y) {
        return that.getRightBound(y) - that.getLeftBound(y);
    };

    return that;
};

// Item Alignment Strategy
var cBaseItemAlignmentStrategy = function(config, offsetX, offsetY, width, height) {
    var that = {
        width: width,
        height: height,
        offsetX: offsetX,
        offsetY: offsetY,
        config: config
    };

    that.rightAlign = function(seatMapItem) {
        seatMapItem.x = Math.round(seatMapItem.boundX + (seatMapItem.boundWidth - seatMapItem.width));
    }

    that.centerAlign = function(seatMapItem) {
        seatMapItem.x = Math.round(seatMapItem.boundX + (seatMapItem.boundWidth - seatMapItem.width) / 2);
    }

    that.leftAlign = function(seatMapItem) {
        seatMapItem.x = Math.round(seatMapItem.boundX);
    }

    that.bottomAlign = function(seatMapItem) {
        seatMapItem.y = Math.round(seatMapItem.boundY + (seatMapItem.boundHeight - seatMapItem.height));
    }

    that.middleAlign = function(seatMapItem) {
        seatMapItem.y = Math.round(seatMapItem.boundY + (seatMapItem.boundHeight - seatMapItem.height) / 2);
    }

    that.topAlign = function(seatMapItem) {
        seatMapItem.y = Math.round(seatMapItem.boundY);
    }

    return that;
}

var cBodyItemAlignmentStrategy = function(config, offsetX, offsetY, width, height) {
    var that = cBaseItemAlignmentStrategy(config, offsetX, offsetY, width, height);

    that.getRowSpacing = function(currentRow, nextRow) {
        if(currentRow.items && currentRow.items[0].type === "exit"){
            return 0;
        }else{
            return that.config.rowSpacing;
        }
    };

    that.alignItem = function(seatItem, row, itemIndex) {
        if (seatItem.type == "seat") {
            that.bottomAlign(seatItem);
            that.centerAlign(seatItem);
        }
    };

    that.getRotationAngle = function(seatItem, rows, rowIndex, itemIndex) {
        return 0;
    };

    return that;
};

var cNoseItemAlignmentStrategy = function(config, offsetX, offsetY, width, height) {
    var that = cBaseItemAlignmentStrategy(config, offsetX, offsetY, width, height);
    var rotationLagrange = new Lagrange(0.012968, 10.35, 1.21451, -22);
    rotationLagrange.addPoint(0.26374, -6.56);
    rotationLagrange.addPoint(0.351758, -9.01);
    rotationLagrange.addPoint(0.481758, -12.41);
    rotationLagrange.addPoint(0.54073, -13.4);
    rotationLagrange.addPoint(0.68264, -14.8);
    rotationLagrange.addPoint(0.82346, -18.31);
    rotationLagrange.addPoint(1, -22);
    rotationLagrange.addPoint(2, -22);

    var isEligibleForCollapsed = function(currentRow, nextRow) {
        // If previous row contains non seat visible item, return false
        var nonSeatFound = false;
        for (var i = 0; i < currentRow.items.length; i++) {
            if (currentRow.items[i].type === "galley" || currentRow.items[i].type === "toilet" || currentRow.items[i].type === "exit") {
                nonSeatFound = true;
                break;
            }
        }
        if (nonSeatFound) return false;
        // If no next row, return false
        if (!nextRow) return false;
        // If next row doesn't contains any seat, return false
        var seatFound = false;
        for (var i = 0; i < nextRow.items.length; i++) {
            if (nextRow.items[i].type === "seat") {
                seatFound = true;
                break;
            }
        }
        if (!seatFound) return false;
        // Return true for other cases
        return true;
    }

    that.getRowSpacing = function(currentRow, nextRow) {
        if (isEligibleForCollapsed(currentRow, nextRow)) {
            return that.config.collapsedRowSpacing;
        } else {
            return that.config.rowSpacing;
        }
    };

    that.alignItem = function(seatItem, row, itemIndex) {
        that.topAlign(seatItem);
        if (itemIndex == 0) {
            that.leftAlign(seatItem);
        } else if (itemIndex == row.items.length - 1) {
            that.rightAlign(seatItem);
        } else {
            that.centerAlign(seatItem);
        }
        seatItem.rotationX = seatItem.x + seatItem.width * 0.47;
        seatItem.rotationY = seatItem.y;
    };

    var getSpanPosition = function(rows, rowIndex, itemIndex) {
        var spanPosition = 0;
        for (var i = 0; i < itemIndex; i++) {
            var span = rows[rowIndex].items[itemIndex].span;
            if (!span) span = 1;
            spanPosition += span;
        }
        return spanPosition;
    }

    var getItemAtSpanPosition = function(rows, rowIndex, spanPosition) {
        if (!rows[rowIndex]) return null;
        var searchPosition = 0;
        for (var i = 0; i < rows[rowIndex].items.length; i++) {
            if (searchPosition == spanPosition) {
                return rows[rowIndex].items[i];
            }
            var span = rows[rowIndex].items[i].span;
            if (!span) span = 1;
            searchPosition += span;
        }
        return null;
    }

    that.getRotationAngle = function(seatItem, rows, rowIndex, itemIndex) {
        var spanPosition = getSpanPosition(rows, rowIndex, itemIndex);
        var prevItem = getItemAtSpanPosition(rows, rowIndex - 1, spanPosition);
        var nextItem = getItemAtSpanPosition(rows, rowIndex + 1, spanPosition);
        // Side Always Rotate
        if (seatItem.seatNo <= "C" || seatItem.seatNo >= "H") {
            var angle;
//            if (prevItem && prevItem.type == "seat") {
//                if (seatItem.seatNo >= "H") {
//                    angle = prevItem.rotationAngle - 5;
//                } else {
//                    angle = prevItem.rotationAngle + 5;
//                }
//            } else {
                angle = rotationLagrange.valueOf((seatItem.y - that.offsetY) / that.height);
                if (seatItem.seatNo >= "H") {
                    return angle *= -1;
                }
//            }
            return angle;
        } else {
            var requireRotate = false;
            // Center only rotate if previous item or next item is seat
            if (prevItem && prevItem.type == "seat") {
                requireRotate = true;
            }
            if (nextItem && nextItem.type == "seat") {
                requireRotate = true;
            }
            if (requireRotate) {
                seatItem.rotationX = seatItem.x + seatItem.width * 0.2;
                seatItem.rotationY = seatItem.y;
                return -21;
            } else {
                seatItem.flip = true;
                return 0;
            }
        }
    };

    return that;
}