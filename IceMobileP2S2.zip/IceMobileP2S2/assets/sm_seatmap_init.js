

var seatSelector = cSeatSelector(passengers, "passengerSelector", "passengerSelectorResult", platform);
var seatMapRenderer = null;
var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
var height = Math.max(document.documentElement.clientHeight, window.innerHeight) - 40;
var realWidth = (deviceWidth / window.devicePixelRatio);

if(width != realWidth && platform == "android") {
	width = realWidth;
}

//for android, need to check the height
if(height < 0) {
	height = (deviceHeight / window.devicePixelRatio) * 0.87;
	var status_bar_height = 25;
	if(window.devicePixelRatio < 1) {
		status_bar_height = 20;
	}else if(window.devicePixelRatio > 1) {
		status_bar_height = 38;
	}
	
	height = height - status_bar_height - 50;
}

if (passengers.length === 1) {	
	height += 40;
}

var r = Raphael("seatMap", width, height, function() {
    var paper = this;
    // Render Seat
    seatMapRenderer = cSeatMapRenderer(paper, width, height, seatSelector, platform);
    var scrollHeight = seatMapRenderer.render(seatMapData);
    // Preselect seats
    for (var i = 0; i < passengers.length; i++) {
        if (passengers[i].seatNo) {
            seatSelector.updateNavPosition(i, true);
            if(seatMapRenderer.getSeat(passengers[i].seatNo)) {
            	console.log("init the seats for selected seat");
            	seatSelector.setSelectedSeatNo(seatMapRenderer.getSeat(passengers[i].seatNo), true);
            }
            
        }
    }
    
    // Enable zoom control
    var panZoom = paper.panzoom({ initialZoom: 1, initialPosition: { x: 0, y: 0}, scrollHeight: scrollHeight, callback:seatMapRenderer });
    panZoom.enable();
    seatSelector.panZoom = panZoom;
    
    // Start Index
    seatSelector.updateNavPosition(seatSelectedIndex);
});



$(document).bind(
    'touchmove',
    function(e) {
        e.preventDefault();
    }
);