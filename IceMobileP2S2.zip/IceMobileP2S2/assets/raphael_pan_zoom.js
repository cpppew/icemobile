/**
 * raphael.pan-zoom plugin 0.2.1
 * Copyright (c) 2012 @author Juan S. Escobar
 * https://github.com/escobar5
 *
 * licensed under the MIT license
 */

(function () {
    'use strict';
    /*jslint browser: true*/
    /*global Raphael*/

    function findPos(obj) {
        var posX = obj.offsetLeft, posY = obj.offsetTop, posArray;
        while (obj.offsetParent) {
            if (obj === document.getElementsByTagName('body')[0]) {
                break;
            } else {
                posX = posX + obj.offsetParent.offsetLeft;
                posY = posY + obj.offsetParent.offsetTop;
                obj = obj.offsetParent;
            }
        }
        posArray = [posX, posY];
        return posArray;
    }

    function getRelativePosition(e, obj) {
        var x, y, pos;
        if (e.pageX || e.pageY) {
            x = e.pageX;
            y = e.pageY;
        } else {
            x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
            y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
        }

        pos = findPos(obj);
        x -= pos[0];
        y -= pos[1];

        return { x: x, y: y };
    }

    var panZoomFunctions = {
            enable: function () {
                this.enabled = true;
            },

            disable: function () {
                this.enabled = false;
            },

            zoomIn: function (steps) {
                this.applyZoom(steps);
            },

            zoomOut: function (steps) {
                this.applyZoom(steps > 0 ? steps * -1 : steps);
            },

            pan: function (deltaX, deltaY) {
                this.applyPan(deltaX * -1, deltaY * -1);
            },

            isDragging: function () {
                return this.dragTime > this.dragThreshold;
            },

            getCurrentPosition: function () {
                return this.currPos;
            },

            getCurrentZoom: function () {
                return this.currZoom;
            },

            checkRequestAnimationFrame: function() {
                var lastTime = 0;
                var vendors = ['ms', 'moz', 'webkit', 'o'];
                for(var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
                    window.requestAnimationFrame = window[vendors[x]+'RequestAnimationFrame'];
                    window.cancelAnimationFrame =
                        window[vendors[x]+'CancelAnimationFrame'] || window[vendors[x]+'CancelRequestAnimationFrame'];
                }

                if (!window.requestAnimationFrame) {
                    window.requestAnimationFrame = function(callback, element) {
                        var currTime = new Date().getTime();
                        var timeToCall = Math.max(0, 16 - (currTime - lastTime));
                        var id = window.setTimeout(function() { callback(currTime + timeToCall); },
                            timeToCall);
                        lastTime = currTime + timeToCall;
                        return id;
                    };
                }

                if (!window.cancelAnimationFrame) {
                    window.cancelAnimationFrame = function(id) {
                        clearTimeout(id);
                    };
                }
            }
        },

        PanZoom = function (el, options) {
            var paper = el,
                container = paper.canvas.parentNode,
                me = this,
                settings = {},
                callback = null,
                topLeft = { x: 0, y: 0 };

            this.enabled = false;
            this.checkRequestAnimationFrame();
            requestAnimationFrame($.proxy( repaint, this ));

            options = options || {};
            callback = options.callback;

            settings.maxZoom = options.maxZoom || 2.5;
            settings.minZoom = options.minZoom || 1;
            settings.initialZoom = options.initialZoom || 1;
            settings.initialPosition = options.initialPosition || { x: 0, y: 0 };

            this.currZoom = settings.initialZoom;
            this.topLeft = settings.initialPosition;
            this.bottomRight = {x: paper.width, y: paper.height};
            this.maxScrollHeight = options.scrollHeight;

            this.scrollTo = function(x, y) {
                var targetTopLeftX = x - (me.bottomRight.x - me.topLeft.x) / 2;
                var targetTopLeftY = y - (me.bottomRight.y - me.topLeft.y) / 2;
                var offsetX = targetTopLeftX - me.topLeft.x;
                var offsetY = targetTopLeftY - me.topLeft.y;
                me.topLeft.x += offsetX;
                me.topLeft.y += offsetY;
                me.bottomRight.x += offsetX;
                me.bottomRight.y += offsetY;

                boundarySafePosition(me.topLeft.x,me.topLeft.y,me.bottomRight.x, me.bottomRight.y);

                requestAnimationFrame($.proxy( repaint, this ));
                callback.showSeatIndicator(me.topLeft.x, me.topLeft.y, me.bottomRight.x, me.bottomRight.y);
            }

            function repaint() {
                paper.setViewBox(me.topLeft.x, me.topLeft.y, me.bottomRight.x - me.topLeft.x, me.bottomRight.y - me.topLeft.y);
               // alert(callback.platform);
                //if (callback.platform != "android") {
                //    callback.showSeatIndicator(me.topLeft.x, me.topLeft.y, me.bottomRight.x, me.bottomRight.y);
               // }
            }

            function boundarySafePosition(x1, y1, x2, y2) {
                // Boundary Check
                if (x1 < 0) {
                    x2 = x2 - x1;
                    x1 = 0;
                } else if (x2 > paper.width) {
                    x1 = x1 - (x2 - paper.width);
                    x2 = paper.width;
                }
                if (y1 < 0) {
                    y2 = y2 - y1;
                    y1 = 0;
                } else if (y2 > me.maxScrollHeight) {
                    y1 = y1 - (y2 - me.maxScrollHeight);
                    y2 = me.maxScrollHeight;
                    // Top Align has higher priority
                    if (y1 < 0) {
                        y2 = y2 - y1;
                        y1 = 0;
                    }
                }
                me.topLeft.x = x1;
                me.bottomRight.x = x2;
                me.topLeft.y = y1;
                me.bottomRight.y = y2;
            }

            repaint();
            // Bind drag event
            Hammer(container).on("drag", function(ev) {
                if (me.enabled) {
                    var targetTopLeftX = me.dragStartTopLeft.x - ev.gesture.deltaX / me.currZoom;
                    var targetBottomRightX =  me.dragStartBottomRight.x - ev.gesture.deltaX / me.currZoom;
                    var targetTopLeftY = me.dragStartTopLeft.y - ev.gesture.deltaY / me.currZoom;
                    var targetBottomRightY = me.dragStartBottomRight.y - ev.gesture.deltaY / me.currZoom;
                    // Boundary Check
                    boundarySafePosition(targetTopLeftX,targetTopLeftY,targetBottomRightX, targetBottomRightY);
                    requestAnimationFrame($.proxy( repaint, this ));
                }
            });

            Hammer(container).on("dragstart", function(ev) {
//                if (callback.platform == "android") {
                    callback.hideSeatIndicator();
//                }
                me.dragStartTopLeft = {x: me.topLeft.x, y: me.topLeft.y};
                me.dragStartBottomRight = {x: me.bottomRight.x, y: me.bottomRight.y};
            });

            Hammer(container).on("dragend", function(ev) {
                callback.showSeatIndicator(me.topLeft.x, me.topLeft.y, me.bottomRight.x, me.bottomRight.y);
            });

            // Bind pinch event
            Hammer(container).on("transformstart", function(ev) {
//                if (callback.platform == "android") {
                    callback.hideSeatIndicator();
//                }
                me.zoomStartRatio = paper.width / (me.bottomRight.x - me.topLeft.x);
                me.zoomCenter = {x: ev.gesture.center.pageX - container.offsetLeft, y:ev.gesture.center.pageY - container.offsetTop};
                me.zoomStartTopLeft = {x: me.topLeft.x, y: me.topLeft.y};
                me.zoomStartBottomRight = {x: me.bottomRight.x, y: me.bottomRight.y};
            });

            Hammer(container).on("transformend", function(ev) {
                me.currZoom = paper.width / (me.bottomRight.x - me.topLeft.x);
                callback.showSeatIndicator(me.topLeft.x, me.topLeft.y, me.bottomRight.x, me.bottomRight.y);
            });

            Hammer(container).on("transform", function(ev) {
                var ratio = ev.gesture.scale;
                if (me.zoomStartRatio * ratio < 1) {
                    me.topLeft = { x:0, y:me.topLeft.y };
                    me.bottomRight = { x:paper.width, y:me.topLeft.y + paper.height };
                    me.currZoom = 1;
                    boundarySafePosition( me.topLeft.x,  me.topLeft.y, me.bottomRight.x, me.bottomRight.y);
                } else {
                    if (me.zoomStartRatio * ratio > settings.maxZoom) {
                        return;
                    }
                    // Convert touch center coordinate to image space
                    var widthRatio = ratio * paper.width;
                    var heightRatio = ratio * paper.height;
                    var ratioX = ratio * me.zoomCenter.x - me.zoomCenter.x;
                    var ratioY = ratio * me.zoomCenter.y - me.zoomCenter.y;
                    var newx1 = ratioX / widthRatio;
                    var newy1 = ratioY / heightRatio;
                    var newx2 = (paper.width + ratioX) / widthRatio;
                    var newy2 = (paper.height + ratioY) / heightRatio;
                    // Map from touch space to image space
                    var x1 = me.zoomStartTopLeft.x + (me.zoomStartBottomRight.x - me.zoomStartTopLeft.x) * newx1;
                    var y1 = me.zoomStartTopLeft.y + (me.zoomStartBottomRight.y - me.zoomStartTopLeft.y) * newy1;
                    var x2 = me.zoomStartTopLeft.x + (me.zoomStartBottomRight.x - me.zoomStartTopLeft.x) * newx2;
                    var y2 = me.zoomStartTopLeft.y + (me.zoomStartBottomRight.y - me.zoomStartTopLeft.y) * newy2;
                    // Boundary Check
                    me.currZoom = paper.width / (me.bottomRight.x - me.topLeft.x);
                    boundarySafePosition(x1, y1, x2, y2);
                }
                requestAnimationFrame($.proxy( repaint, this ));
            });
        };

    PanZoom.prototype = panZoomFunctions;

    Raphael.fn.panzoom = {};

    Raphael.fn.panzoom = function (options) {
        var paper = this;
        return new PanZoom(paper, options);
    };

}());